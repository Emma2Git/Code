---
name: Clerk Expo tokenCache on Web
description: tokenCache from @clerk/expo/token-cache uses SecureStore which crashes silently on web, causing ClerkLoaded to never render (blank white screen).
---

## Rule
When using `@clerk/expo` with Expo Router, only pass `tokenCache` to `ClerkProvider` on native platforms. On web, omit it.

```typescript
import { Platform } from "react-native";
import { tokenCache } from "@clerk/expo/token-cache";

const nativeTokenCache = Platform.OS !== "web" ? tokenCache : undefined;

<ClerkProvider publishableKey={key} tokenCache={nativeTokenCache}>
```

**Why:** `expo-secure-store` (used by the token cache) does not work in browser/web contexts. Passing `tokenCache` on web causes `ClerkLoaded` to silently fail — it never renders children, resulting in a permanently blank white screen with no error.

**How to apply:** Any time ClerkProvider is set up in an Expo app that targets both native and web.
