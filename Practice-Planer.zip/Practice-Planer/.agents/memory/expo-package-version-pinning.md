---
name: Expo package version pinning
description: pnpm add for an expo-* package can resolve a version incompatible with the pinned Expo SDK
---

`pnpm add <expo-package>` resolves the latest npm version, which can be far ahead of what the
project's pinned Expo SDK expects (e.g. `expo-notifications@^57` installed while the app used
Expo SDK `~54`, which expects `~0.32.x`).

**Why:** Expo SDK versions and their compatible native module versions are tracked independently
from npm's normal semver resolution. A mismatched version can fail at build/runtime in ways not
caught by typecheck.

**How to apply:** After `pnpm add`-ing any `expo-*` package, run
`npx expo install <package> --check` inside the app dir to see the expected version, and
reinstall with that exact range if it differs (e.g. `pnpm add expo-notifications@~0.32.17`).
