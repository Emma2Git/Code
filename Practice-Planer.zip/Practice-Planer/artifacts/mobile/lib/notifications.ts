import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

const REMINDER_PREFIX = "eintrag-";

export type ReminderPermissionResult = "granted" | "denied" | "blocked";

export async function getReminderPermissionStatus(): Promise<Notifications.PermissionStatus> {
  const { status } = await Notifications.getPermissionsAsync();
  return status;
}

export async function requestReminderPermission(): Promise<ReminderPermissionResult> {
  const current = await Notifications.getPermissionsAsync();
  if (current.status === "granted") return "granted";

  if (!current.canAskAgain) return "blocked";

  const result = await Notifications.requestPermissionsAsync();
  if (result.status === "granted") return "granted";
  return result.canAskAgain ? "denied" : "blocked";
}

export interface ReminderInput {
  id: string;
  datum: string;
  uhrzeit: string;
  stueckName: string;
  dauerMinuten: number;
}

function parseDateTime(datum: string, uhrzeit: string): Date | null {
  const [year, month, day] = datum.split("-").map(Number);
  const [hour, minute] = uhrzeit.split(":").map(Number);
  if (!year || !month || !day || hour === undefined || minute === undefined) return null;
  const date = new Date(year, month - 1, day, hour, minute, 0, 0);
  if (Number.isNaN(date.getTime())) return null;
  return date;
}

export async function syncReminders(eintraege: ReminderInput[]): Promise<void> {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  const ours = scheduled.filter(n => n.identifier.startsWith(REMINDER_PREFIX));
  await Promise.all(ours.map(n => Notifications.cancelScheduledNotificationAsync(n.identifier)));

  const now = new Date();

  for (const eintrag of eintraege) {
    const when = parseDateTime(eintrag.datum, eintrag.uhrzeit);
    if (!when || when.getTime() <= now.getTime()) continue;

    await Notifications.scheduleNotificationAsync({
      identifier: `${REMINDER_PREFIX}${eintrag.id}`,
      content: {
        title: "Übungszeit! 🎹",
        body: `${eintrag.stueckName} · ${eintrag.dauerMinuten} Min.`,
        sound: Platform.OS === "ios" ? "default" : undefined,
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: when,
      },
    });
  }
}

export async function cancelAllReminders(): Promise<void> {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  const ours = scheduled.filter(n => n.identifier.startsWith(REMINDER_PREFIX));
  await Promise.all(ours.map(n => Notifications.cancelScheduledNotificationAsync(n.identifier)));
}
