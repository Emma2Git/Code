import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '@clerk/expo';
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';

import {
  cancelAllReminders,
  requestReminderPermission,
  syncReminders,
  type ReminderPermissionResult,
} from '@/lib/notifications';

export const STUECK_FARBEN = [
  '#E74C3C', '#E91E8C', '#9C27B0', '#5C6BC0',
  '#1E88E5', '#00ACC1', '#43A047', '#F9A825',
  '#FB8C00', '#795548',
];

export interface Stueck {
  id: string;
  name: string;
  komponist?: string;
  notizen?: string;
  farbe: string;
  foto?: string;
}

export interface UebungsEintrag {
  id: string;
  datum: string;
  stueckId: string;
  dauerMinuten: number;
  notizen?: string;
  uhrzeit?: string;
  erledigt: boolean;
}

export interface StoppuhrSession {
  id: string;
  stueckId: string;
  sekunden: number;
  datum: string;
}

export interface Termin {
  id: string;
  datum: string;
  endDatum?: string;
  name: string;
  uhrzeit?: string;
  notizen?: string;
  farbe?: string;
}

interface AppContextType {
  stuecke: Stueck[];
  eintraege: UebungsEintrag[];
  sessions: StoppuhrSession[];
  termine: Termin[];
  isSyncing: boolean;
  erinnerungenAktiv: boolean;
  setErinnerungenAktiv: (aktiv: boolean) => Promise<ReminderPermissionResult | 'ok'>;
  addStueck: (name: string, komponist: string | undefined, notizen: string | undefined, farbe: string, foto?: string) => void;
  updateStueck: (id: string, name: string, komponist: string | undefined, notizen: string | undefined, farbe: string, foto?: string) => void;
  deleteStueck: (id: string) => void;
  addEintrag: (datum: string, stueckId: string, dauerMinuten: number, notizen?: string, uhrzeit?: string) => void;
  updateEintrag: (id: string, dauerMinuten: number, notizen?: string, uhrzeit?: string) => void;
  deleteEintrag: (id: string) => void;
  toggleErledigt: (id: string) => void;
  addSession: (stueckId: string, sekunden: number) => void;
  deleteSession: (id: string) => void;
  addTermin: (datum: string, name: string, uhrzeit?: string, notizen?: string, endDatum?: string, farbe?: string) => void;
  updateTermin: (id: string, name: string, uhrzeit?: string, notizen?: string, endDatum?: string, farbe?: string) => void;
  deleteTermin: (id: string) => void;
  getEintraegeForDate: (datum: string) => UebungsEintrag[];
  getTermineForDate: (datum: string) => Termin[];
  getStueckById: (id: string) => Stueck | undefined;
  getTotalSekundenForStueck: (stueckId: string) => number;
}

const AppContext = createContext<AppContextType | null>(null);

const KEYS = {
  stuecke: '@klavierplaner_stuecke_v2',
  eintraege: '@klavierplaner_eintraege_v2',
  sessions: '@klavierplaner_sessions',
  termine: '@klavierplaner_termine_v1',
  erinnerungenAktiv: '@klavierplaner_erinnerungen_aktiv',
};

function makeId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 6);
}

const API_BASE = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
  : '';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [stuecke, setStuecke] = useState<Stueck[]>([]);
  const [eintraege, setEintraege] = useState<UebungsEintrag[]>([]);
  const [sessions, setSessions] = useState<StoppuhrSession[]>([]);
  const [termine, setTermine] = useState<Termin[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [erinnerungenAktiv, setErinnerungenAktivState] = useState(false);

  const { isSignedIn, isLoaded, getToken } = useAuth();
  const signedInRef = useRef(false);
  const skipNextSyncRef = useRef(false);
  const syncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const [s, e, se, t, r] = await Promise.all([
          AsyncStorage.getItem(KEYS.stuecke),
          AsyncStorage.getItem(KEYS.eintraege),
          AsyncStorage.getItem(KEYS.sessions),
          AsyncStorage.getItem(KEYS.termine),
          AsyncStorage.getItem(KEYS.erinnerungenAktiv),
        ]);
        if (s) setStuecke(JSON.parse(s));
        if (e) setEintraege(JSON.parse(e));
        if (se) setSessions(JSON.parse(se));
        if (t) setTermine(JSON.parse(t));
        if (r) setErinnerungenAktivState(JSON.parse(r));
      } catch {}
    }
    load();
  }, []);

  const setErinnerungenAktiv = useCallback(async (aktiv: boolean): Promise<ReminderPermissionResult | 'ok'> => {
    if (aktiv) {
      const result = await requestReminderPermission();
      if (result !== 'granted') return result;
    } else {
      await cancelAllReminders();
    }
    setErinnerungenAktivState(aktiv);
    AsyncStorage.setItem(KEYS.erinnerungenAktiv, JSON.stringify(aktiv)).catch(() => {});
    return 'ok';
  }, []);

  useEffect(() => {
    if (!erinnerungenAktiv) return;
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const reminders = eintraege
      .filter(e => !e.erledigt && e.uhrzeit && e.datum >= todayStr)
      .map(e => {
        const stueck = stuecke.find(s => s.id === e.stueckId);
        return {
          id: e.id,
          datum: e.datum,
          uhrzeit: e.uhrzeit as string,
          stueckName: stueck?.name ?? 'Übung',
          dauerMinuten: e.dauerMinuten,
        };
      });
    syncReminders(reminders).catch(() => {});
  }, [erinnerungenAktiv, eintraege, stuecke]);

  useEffect(() => {
    if (!isLoaded) return;

    if (isSignedIn && !signedInRef.current) {
      signedInRef.current = true;
      loadFromCloud();
    } else if (!isSignedIn && signedInRef.current) {
      signedInRef.current = false;
    }
  }, [isLoaded, isSignedIn]);

  async function loadFromCloud() {
    try {
      setIsSyncing(true);
      const token = await getToken();
      if (!token) return;
      const res = await fetch(`${API_BASE}/api/data`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return;
      const data = await res.json();
      skipNextSyncRef.current = true;
      setStuecke(data.stuecke ?? []);
      setEintraege(data.eintraege ?? []);
      setSessions(data.sessions ?? []);
      setTermine(data.termine ?? []);
      AsyncStorage.setItem(KEYS.stuecke, JSON.stringify(data.stuecke ?? [])).catch(() => {});
      AsyncStorage.setItem(KEYS.eintraege, JSON.stringify(data.eintraege ?? [])).catch(() => {});
      AsyncStorage.setItem(KEYS.sessions, JSON.stringify(data.sessions ?? [])).catch(() => {});
      AsyncStorage.setItem(KEYS.termine, JSON.stringify(data.termine ?? [])).catch(() => {});
      setTimeout(() => { skipNextSyncRef.current = false; }, 200);
    } catch {} finally {
      setIsSyncing(false);
    }
  }

  async function syncToCloud(s: Stueck[], e: UebungsEintrag[], se: StoppuhrSession[], t: Termin[]) {
    try {
      const token = await getToken();
      if (!token) return;
      await fetch(`${API_BASE}/api/data`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ stuecke: s, eintraege: e, sessions: se, termine: t }),
      });
    } catch {}
  }

  useEffect(() => {
    if (!isSignedIn || !isLoaded || skipNextSyncRef.current) return;

    if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
    syncTimerRef.current = setTimeout(() => {
      if (!skipNextSyncRef.current) {
        syncToCloud(stuecke, eintraege, sessions, termine);
      }
    }, 1500);

    return () => {
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
    };
  }, [stuecke, eintraege, sessions, termine, isSignedIn, isLoaded]);

  const save = useCallback((key: string, data: unknown) => {
    AsyncStorage.setItem(key, JSON.stringify(data)).catch(() => {});
  }, []);

  const addStueck = useCallback((name: string, komponist: string | undefined, notizen: string | undefined, farbe: string, foto?: string) => {
    const neu: Stueck = { id: makeId(), name, komponist, notizen, farbe, foto };
    setStuecke(prev => { const u = [...prev, neu]; save(KEYS.stuecke, u); return u; });
  }, [save]);

  const updateStueck = useCallback((id: string, name: string, komponist: string | undefined, notizen: string | undefined, farbe: string, foto?: string) => {
    setStuecke(prev => { const u = prev.map(s => s.id === id ? { ...s, name, komponist, notizen, farbe, foto } : s); save(KEYS.stuecke, u); return u; });
  }, [save]);

  const deleteStueck = useCallback((id: string) => {
    setStuecke(prev => { const u = prev.filter(s => s.id !== id); save(KEYS.stuecke, u); return u; });
    setEintraege(prev => { const u = prev.filter(e => e.stueckId !== id); save(KEYS.eintraege, u); return u; });
    setSessions(prev => { const u = prev.filter(s => s.stueckId !== id); save(KEYS.sessions, u); return u; });
  }, [save]);

  const addEintrag = useCallback((datum: string, stueckId: string, dauerMinuten: number, notizen?: string, uhrzeit?: string) => {
    const neu: UebungsEintrag = { id: makeId(), datum, stueckId, dauerMinuten, notizen, uhrzeit, erledigt: false };
    setEintraege(prev => { const u = [...prev, neu]; save(KEYS.eintraege, u); return u; });
  }, [save]);

  const updateEintrag = useCallback((id: string, dauerMinuten: number, notizen?: string, uhrzeit?: string) => {
    setEintraege(prev => { const u = prev.map(e => e.id === id ? { ...e, dauerMinuten, notizen, uhrzeit } : e); save(KEYS.eintraege, u); return u; });
  }, [save]);

  const deleteEintrag = useCallback((id: string) => {
    setEintraege(prev => { const u = prev.filter(e => e.id !== id); save(KEYS.eintraege, u); return u; });
  }, [save]);

  const toggleErledigt = useCallback((id: string) => {
    setEintraege(prev => { const u = prev.map(e => e.id === id ? { ...e, erledigt: !e.erledigt } : e); save(KEYS.eintraege, u); return u; });
  }, [save]);

  const addSession = useCallback((stueckId: string, sekunden: number) => {
    const today = new Date();
    const datum = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const neu: StoppuhrSession = { id: makeId(), stueckId, sekunden, datum };

    setSessions(prev => { const u = [...prev, neu]; save(KEYS.sessions, u); return u; });

    const prevTotal = sessions
      .filter(s => s.stueckId === stueckId && s.datum === datum)
      .reduce((sum, s) => sum + s.sekunden, 0);
    const newTotal = prevTotal + sekunden;

    setEintraege(prev => {
      const updated = prev.map(e => {
        if (e.stueckId === stueckId && e.datum === datum && !e.erledigt && e.dauerMinuten * 60 <= newTotal) {
          return { ...e, erledigt: true };
        }
        return e;
      });
      if (updated.some((e, i) => e.erledigt !== prev[i].erledigt)) {
        save(KEYS.eintraege, updated);
      }
      return updated;
    });
  }, [save, sessions]);

  const deleteSession = useCallback((id: string) => {
    setSessions(prev => { const u = prev.filter(s => s.id !== id); save(KEYS.sessions, u); return u; });
  }, [save]);

  const addTermin = useCallback((datum: string, name: string, uhrzeit?: string, notizen?: string, endDatum?: string, farbe?: string) => {
    const neu: Termin = { id: makeId(), datum, endDatum, name, uhrzeit, notizen, farbe };
    setTermine(prev => { const u = [...prev, neu]; save(KEYS.termine, u); return u; });
  }, [save]);

  const updateTermin = useCallback((id: string, name: string, uhrzeit?: string, notizen?: string, endDatum?: string, farbe?: string) => {
    setTermine(prev => { const u = prev.map(t => t.id === id ? { ...t, name, uhrzeit, notizen, endDatum, farbe } : t); save(KEYS.termine, u); return u; });
  }, [save]);

  const deleteTermin = useCallback((id: string) => {
    setTermine(prev => { const u = prev.filter(t => t.id !== id); save(KEYS.termine, u); return u; });
  }, [save]);

  const getEintraegeForDate = useCallback((datum: string) => eintraege.filter(e => e.datum === datum), [eintraege]);
  const getTermineForDate = useCallback((datum: string) =>
    termine.filter(t => t.endDatum ? (t.datum <= datum && datum <= t.endDatum) : t.datum === datum),
  [termine]);
  const getStueckById = useCallback((id: string) => stuecke.find(s => s.id === id), [stuecke]);
  const getTotalSekundenForStueck = useCallback((stueckId: string) =>
    sessions.filter(s => s.stueckId === stueckId).reduce((sum, s) => sum + s.sekunden, 0), [sessions]);

  return (
    <AppContext.Provider value={{
      stuecke, eintraege, sessions, termine, isSyncing,
      erinnerungenAktiv, setErinnerungenAktiv,
      addStueck, updateStueck, deleteStueck,
      addEintrag, updateEintrag, deleteEintrag, toggleErledigt,
      addSession, deleteSession,
      addTermin, updateTermin, deleteTermin,
      getEintraegeForDate, getTermineForDate, getStueckById, getTotalSekundenForStueck,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextType {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
