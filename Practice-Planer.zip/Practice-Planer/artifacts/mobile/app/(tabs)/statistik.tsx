import { Feather } from "@expo/vector-icons";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import React, { useRef, useState } from "react";
import {
  Dimensions,
  NativeScrollEvent,
  NativeSyntheticEvent,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

function formatDuration(seconds: number): string {
  if (seconds === 0) return "0 Min.";
  if (seconds < 60) return `${seconds} Sek.`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return s > 0 ? `${m} Min. ${s} Sek.` : `${m} Min.`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm > 0 ? `${h} Std. ${rm} Min.` : `${h} Std.`;
}

function toDateString(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

type FilterType = "gesamt" | "woche" | "monat";

export default function StatistikScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { stuecke, sessions, eintraege } = useApp();
  const [filter, setFilter] = useState<FilterType>("gesamt");
  const [goalIndex, setGoalIndex] = useState(0);
  const goalScrollRef = useRef<ScrollView>(null);
  const CARD_WIDTH = Dimensions.get("window").width - 32;

  function getDateRange(): { mondayStr?: string; monthStr?: string } {
    const now = new Date();
    if (filter === "woche") {
      const dow = now.getDay();
      const diff = dow === 0 ? 6 : dow - 1;
      const monday = new Date(now);
      monday.setDate(now.getDate() - diff);
      monday.setHours(0, 0, 0, 0);
      return { mondayStr: toDateString(monday) };
    }
    if (filter === "monat") {
      return { monthStr: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}` };
    }
    return {};
  }

  function getFilteredSessions() {
    const { mondayStr, monthStr } = getDateRange();
    if (filter === "gesamt") return sessions;
    if (filter === "woche" && mondayStr) return sessions.filter(s => s.datum >= mondayStr);
    if (filter === "monat" && monthStr) return sessions.filter(s => s.datum.startsWith(monthStr));
    return sessions;
  }

  function getFilteredEintraege() {
    const { mondayStr, monthStr } = getDateRange();
    if (filter === "gesamt") return eintraege;
    if (filter === "woche" && mondayStr) return eintraege.filter(e => e.datum >= mondayStr);
    if (filter === "monat" && monthStr) return eintraege.filter(e => e.datum.startsWith(monthStr));
    return eintraege;
  }

  const filteredSessions = getFilteredSessions();
  const filteredEintraege = getFilteredEintraege();
  const totalSeconds = filteredSessions.reduce((sum, s) => sum + s.sekunden, 0);

  const goalsPerStueck = stuecke
    .map(st => {
      const planned = filteredEintraege
        .filter(e => e.stueckId === st.id)
        .reduce((sum, e) => sum + e.dauerMinuten, 0);
      const actualSec = filteredSessions
        .filter(s => s.stueckId === st.id)
        .reduce((sum, s) => sum + s.sekunden, 0);
      return { stueck: st, plannedMinutes: planned, actualSec };
    })
    .filter(x => x.plannedMinutes > 0 || x.actualSec > 0);

  const statsPerStueck = stuecke
    .map(st => {
      const secs = filteredSessions
        .filter(s => s.stueckId === st.id)
        .reduce((sum, s) => sum + s.sekunden, 0);
      return { stueck: st, sekunden: secs };
    })
    .filter(x => x.sekunden > 0)
    .sort((a, b) => b.sekunden - a.sekunden);

  const maxSekunden = statsPerStueck[0]?.sekunden ?? 1;

  const topPad = Platform.OS === "web" ? insets.top + 67 : isLiquidGlassAvailable() ? insets.top : 0;
  const s = makeStyles(colors);

  return (
    <View style={[s.container, { paddingTop: topPad }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 40 + (Platform.OS === "web" ? 34 : 0) }}>

        {/* Filter Tabs */}
        <View style={s.filterRow}>
          {(["gesamt", "woche", "monat"] as FilterType[]).map(f => (
            <TouchableOpacity
              key={f}
              style={[s.filterBtn, filter === f && s.filterBtnActive]}
              onPress={() => setFilter(f)}
            >
              <Text style={[s.filterText, filter === f && s.filterTextActive]}>
                {f === "gesamt" ? "Gesamt" : f === "woche" ? "Diese Woche" : "Dieser Monat"}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Total Summary */}
        <View style={s.summaryCard}>
          <View style={s.summaryItem}>
            <Feather name="clock" size={22} color={colors.primary} />
            <Text style={s.summaryValue}>{formatDuration(totalSeconds)}</Text>
            <Text style={s.summaryLabel}>Gesamtzeit</Text>
          </View>
          <View style={s.summaryDivider} />
          <View style={s.summaryItem}>
            <Feather name="layers" size={22} color={colors.primary} />
            <Text style={s.summaryValue}>{filteredSessions.length}</Text>
            <Text style={s.summaryLabel}>Sessions</Text>
          </View>
          <View style={s.summaryDivider} />
          <View style={s.summaryItem}>
            <Feather name="music" size={22} color={colors.primary} />
            <Text style={s.summaryValue}>{statsPerStueck.length}</Text>
            <Text style={s.summaryLabel}>{statsPerStueck.length === 1 ? "Stück" : "Stücke"}</Text>
          </View>
        </View>

        {/* Per-Piece Goal Carousel */}
        {goalsPerStueck.length > 0 && (
          <View style={s.goalSection}>
            <Text style={s.sectionTitle}>Übungsziele</Text>
            <ScrollView
              ref={goalScrollRef}
              horizontal
              pagingEnabled={false}
              snapToInterval={CARD_WIDTH + 12}
              snapToAlignment="start"
              decelerationRate="fast"
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}
              onScroll={(e: NativeSyntheticEvent<NativeScrollEvent>) => {
                const idx = Math.round(e.nativeEvent.contentOffset.x / (CARD_WIDTH + 12));
                setGoalIndex(Math.max(0, Math.min(idx, goalsPerStueck.length - 1)));
              }}
              scrollEventThrottle={16}
            >
              {goalsPerStueck.map(({ stueck, plannedMinutes: planned, actualSec }) => {
                const plannedSec = planned * 60;
                const progress = planned > 0 ? Math.min(actualSec / plannedSec, 1) : null;
                const done = progress !== null && progress >= 1;
                const actualMin = Math.floor(actualSec / 60);
                const actualSecRem = actualSec % 60;
                const actualLabel = actualSec === 0 ? "—"
                  : actualMin > 0 && actualSecRem > 0 ? `${actualMin} Min. ${actualSecRem} Sek.`
                  : actualMin > 0 ? `${actualMin} Min.`
                  : `${actualSecRem} Sek.`;
                return (
                  <View key={stueck.id} style={[s.goalCard, { width: CARD_WIDTH }]}>
                    <View style={[s.goalColorStripe, { backgroundColor: stueck.farbe }]} />
                    <View style={s.goalCardInner}>
                      <View style={s.goalHeader}>
                        <View style={{ flex: 1 }}>
                          <Text style={s.goalStueckName} numberOfLines={1}>{stueck.name}</Text>
                          {stueck.komponist ? <Text style={s.goalKomp}>{stueck.komponist}</Text> : null}
                        </View>
                        <Feather
                          name={done ? "check-circle" : "target"}
                          size={18}
                          color={done ? "#43A047" : stueck.farbe}
                        />
                      </View>
                      <View style={s.goalRow}>
                        <View style={s.goalItem}>
                          <Text style={s.goalItemLabel}>Geplant</Text>
                          <Text style={s.goalItemValue}>{planned > 0 ? `${planned} Min.` : "—"}</Text>
                        </View>
                        <View style={s.goalDivider} />
                        <View style={s.goalItem}>
                          <Text style={s.goalItemLabel}>Gestoppt</Text>
                          <Text style={[s.goalItemValue, done && { color: "#43A047" }]}>
                            {actualLabel}
                          </Text>
                        </View>
                        {progress !== null && (
                          <>
                            <View style={s.goalDivider} />
                            <View style={s.goalItem}>
                              <Text style={s.goalItemLabel}>Fortschritt</Text>
                              <Text style={[s.goalItemValue, { color: done ? "#43A047" : stueck.farbe }]}>
                                {Math.floor(progress * 100)} %
                              </Text>
                            </View>
                          </>
                        )}
                      </View>
                      {progress !== null && (
                        <View style={s.goalTrack}>
                          <View style={[s.goalFill, {
                            width: `${Math.floor(progress * 100)}%` as any,
                            backgroundColor: done ? "#43A047" : stueck.farbe,
                          }]} />
                        </View>
                      )}
                    </View>
                  </View>
                );
              })}
            </ScrollView>
            {goalsPerStueck.length > 1 && (
              <View style={s.dots}>
                {goalsPerStueck.map((_, i) => (
                  <View key={i} style={[s.dot, i === goalIndex && s.dotActive]} />
                ))}
              </View>
            )}
          </View>
        )}

        {/* Per Piece Stats */}
        {statsPerStueck.length === 0 ? (
          <View style={s.empty}>
            <Feather name="bar-chart-2" size={44} color={colors.mutedForeground} />
            <Text style={s.emptyTitle}>Noch keine Daten</Text>
            <Text style={s.emptySub}>
              Nutze die Stoppuhr, um deine Übungszeiten aufzuzeichnen
            </Text>
          </View>
        ) : (
          <>
            <Text style={s.sectionTitle}>Zeit pro Stück</Text>
            {statsPerStueck.map(({ stueck, sekunden }) => (
              <View key={stueck.id} style={s.statCard}>
                <View style={[s.statColorBar, { backgroundColor: stueck.farbe }]} />
                <View style={s.statContent}>
                  <View style={s.statHeader}>
                    <View style={s.statNameBox}>
                      <Text style={s.statName}>{stueck.name}</Text>
                      {stueck.komponist ? (
                        <Text style={s.statKomp}>{stueck.komponist}</Text>
                      ) : null}
                    </View>
                    <Text style={[s.statTime, { color: stueck.farbe }]}>
                      {formatDuration(sekunden)}
                    </Text>
                  </View>
                  <View style={s.barTrack}>
                    <View
                      style={[
                        s.barFill,
                        {
                          width: `${(sekunden / maxSekunden) * 100}%` as any,
                          backgroundColor: stueck.farbe,
                        },
                      ]}
                    />
                  </View>
                  <Text style={s.statSessions}>
                    {filteredSessions.filter(s => s.stueckId === stueck.id).length} Sessions
                  </Text>
                </View>
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    filterRow: { flexDirection: "row", paddingHorizontal: 16, paddingTop: 16, paddingBottom: 8, gap: 8 },
    filterBtn: { flex: 1, alignItems: "center", paddingVertical: 8, borderRadius: 10, backgroundColor: colors.muted },
    filterBtnActive: { backgroundColor: colors.primary },
    filterText: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground },
    filterTextActive: { color: colors.primaryForeground },
    summaryCard: {
      flexDirection: "row",
      backgroundColor: colors.card,
      marginHorizontal: 16,
      marginBottom: 16,
      borderRadius: 16,
      padding: 16,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.07,
      shadowRadius: 4,
      elevation: 2,
    },
    summaryItem: { flex: 1, alignItems: "center", gap: 4 },
    summaryDivider: { width: 1, backgroundColor: colors.border, marginVertical: 4 },
    summaryValue: { fontSize: 17, fontFamily: "Inter_700Bold", color: colors.foreground, textAlign: "center" },
    summaryLabel: { fontSize: 11, fontFamily: "Inter_400Regular", color: colors.mutedForeground },
    empty: { alignItems: "center", paddingTop: 48, gap: 12, paddingHorizontal: 32 },
    emptyTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    emptySub: { fontSize: 14, fontFamily: "Inter_400Regular", color: colors.mutedForeground, textAlign: "center", lineHeight: 20 },
    sectionTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.6, paddingHorizontal: 20, marginBottom: 10 },
    statCard: {
      flexDirection: "row",
      backgroundColor: colors.card,
      marginHorizontal: 16,
      marginBottom: 10,
      borderRadius: 14,
      overflow: "hidden",
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.06,
      shadowRadius: 3,
      elevation: 2,
    },
    statColorBar: { width: 5 },
    statContent: { flex: 1, padding: 14 },
    statHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 10 },
    statNameBox: { flex: 1 },
    statName: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    statKomp: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    statTime: { fontSize: 15, fontFamily: "Inter_700Bold" },
    barTrack: { height: 6, backgroundColor: colors.muted, borderRadius: 3, overflow: "hidden", marginBottom: 6 },
    barFill: { height: "100%", borderRadius: 3 },
    statSessions: { fontSize: 11, fontFamily: "Inter_400Regular", color: colors.mutedForeground },
    goalSection: { marginBottom: 16 },
    goalCard: {
      backgroundColor: colors.card,
      borderRadius: 16,
      overflow: "hidden",
      flexDirection: "row",
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.07,
      shadowRadius: 4,
      elevation: 2,
    },
    goalColorStripe: { width: 5 },
    goalCardInner: { flex: 1, padding: 16, gap: 12 },
    goalHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
    goalStueckName: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    goalKomp: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    goalRow: { flexDirection: "row", alignItems: "center" },
    goalItem: { flex: 1, alignItems: "center", gap: 3 },
    goalItemLabel: { fontSize: 10, fontFamily: "Inter_400Regular", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.4 },
    goalItemValue: { fontSize: 16, fontFamily: "Inter_700Bold", color: colors.foreground },
    goalDivider: { width: 1, height: 36, backgroundColor: colors.border },
    goalTrack: { height: 8, backgroundColor: colors.muted, borderRadius: 4, overflow: "hidden" },
    goalFill: { height: "100%", borderRadius: 4 },
    dots: { flexDirection: "row", justifyContent: "center", gap: 6, marginTop: 10 },
    dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.muted },
    dotActive: { backgroundColor: colors.primary, width: 18 },
  });
}
