import { useAuth } from "@clerk/expo";
import { BlurView } from "expo-blur";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import { Redirect, Tabs } from "expo-router";
import { Icon, Label, NativeTabs } from "expo-router/unstable-native-tabs";
import { SymbolView } from "expo-symbols";
import { Feather } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View, useColorScheme } from "react-native";

import { useColors } from "@/hooks/useColors";

function NativeTabLayout() {
  const colors = useColors();
  return (
    <NativeTabs tintColor={colors.primary}>
      <NativeTabs.Trigger name="index">
        <Icon sf={{ default: "house", selected: "house.fill" }} />
        <Label>Menü</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="kalender">
        <Icon sf={{ default: "calendar", selected: "calendar.fill" }} />
        <Label>Kalender</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="stoppuhr">
        <Icon sf={{ default: "stopwatch", selected: "stopwatch.fill" }} />
        <Label>Stoppuhr</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="statistik">
        <Icon sf={{ default: "chart.bar", selected: "chart.bar.fill" }} />
        <Label>Statistik</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="stuecke">
        <Icon sf={{ default: "music.note.list", selected: "music.note.list" }} />
        <Label>Stücke</Label>
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}

function ClassicTabLayout() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: true,
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.foreground,
        headerTitleStyle: { fontFamily: "Inter_600SemiBold", fontSize: 17 },
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : colors.background,
          borderTopWidth: isWeb ? 1 : 0,
          borderTopColor: colors.border,
          elevation: 0,
          ...(isWeb ? { height: 84 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={100}
              tint={isDark ? "dark" : "light"}
              style={StyleSheet.absoluteFill}
            />
          ) : isWeb ? (
            <View style={[StyleSheet.absoluteFill, { backgroundColor: colors.background }]} />
          ) : null,
        tabBarLabelStyle: { fontFamily: "Inter_500Medium", fontSize: 10 },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Menü",
          tabBarIcon: ({ color }) =>
            isIOS ? <SymbolView name="house.fill" tintColor={color} size={22} /> : <Feather name="home" size={21} color={color} />,
        }}
      />
      <Tabs.Screen
        name="kalender"
        options={{
          title: "Kalender",
          tabBarIcon: ({ color }) =>
            isIOS ? <SymbolView name="calendar" tintColor={color} size={22} /> : <Feather name="calendar" size={21} color={color} />,
        }}
      />
      <Tabs.Screen
        name="stoppuhr"
        options={{
          title: "Stoppuhr",
          tabBarIcon: ({ color }) =>
            isIOS ? <SymbolView name="stopwatch.fill" tintColor={color} size={22} /> : <Feather name="clock" size={21} color={color} />,
        }}
      />
      <Tabs.Screen
        name="statistik"
        options={{
          title: "Statistik",
          tabBarIcon: ({ color }) =>
            isIOS ? <SymbolView name="chart.bar.fill" tintColor={color} size={22} /> : <Feather name="bar-chart-2" size={21} color={color} />,
        }}
      />
      <Tabs.Screen
        name="stuecke"
        options={{
          title: "Stücke",
          tabBarIcon: ({ color }) =>
            isIOS ? <SymbolView name="music.note.list" tintColor={color} size={22} /> : <Feather name="music" size={21} color={color} />,
        }}
      />
    </Tabs>
  );
}

export default function TabLayout() {
  const { isSignedIn, isLoaded } = useAuth();

  if (!isLoaded) return null;
  if (!isSignedIn) return <Redirect href="/(auth)/sign-in" />;

  if (isLiquidGlassAvailable()) return <NativeTabLayout />;
  return <ClassicTabLayout />;
}
