import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import * as ImagePicker from "expo-image-picker";
import React, { useState } from "react";
import {
  ActionSheetIOS,
  Alert,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { STUECK_FARBEN, useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

export default function StueckeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { stuecke, addStueck, updateStueck, deleteStueck, eintraege } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [nameInput, setNameInput] = useState("");
  const [komponistInput, setKomponistInput] = useState("");
  const [notizenInput, setNotizenInput] = useState("");
  const [selectedFarbe, setSelectedFarbe] = useState(STUECK_FARBEN[0] ?? "#E74C3C");
  const [fotoUri, setFotoUri] = useState<string | undefined>(undefined);
  const [fotoLoading, setFotoLoading] = useState(false);

  function openAddModal() {
    setEditingId(null);
    setNameInput("");
    setKomponistInput("");
    setNotizenInput("");
    setSelectedFarbe(STUECK_FARBEN[0] ?? "#E74C3C");
    setFotoUri(undefined);
    setShowModal(true);
  }

  function openEditModal(id: string) {
    const stueck = stuecke.find(s => s.id === id);
    if (!stueck) return;
    setEditingId(id);
    setNameInput(stueck.name);
    setKomponistInput(stueck.komponist ?? "");
    setNotizenInput(stueck.notizen ?? "");
    setSelectedFarbe(stueck.farbe);
    setFotoUri(stueck.foto);
    setShowModal(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  function closeModal() {
    setShowModal(false);
    setEditingId(null);
    setNameInput("");
    setKomponistInput("");
    setNotizenInput("");
    setSelectedFarbe(STUECK_FARBEN[0] ?? "#E74C3C");
    setFotoUri(undefined);
  }

  async function pickFromLibrary() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Erlaubnis nötig", "Bitte erlaube den Zugriff auf deine Fotos in den Einstellungen.");
      return;
    }
    setFotoLoading(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: "images",
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.55,
        base64: true,
      });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        const dataUri = asset.base64
          ? `data:image/jpeg;base64,${asset.base64}`
          : asset.uri;
        setFotoUri(dataUri);
      }
    } finally {
      setFotoLoading(false);
    }
  }

  async function pickFromCamera() {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Erlaubnis nötig", "Bitte erlaube den Zugriff auf die Kamera in den Einstellungen.");
      return;
    }
    setFotoLoading(true);
    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.55,
        base64: true,
      });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        const dataUri = asset.base64
          ? `data:image/jpeg;base64,${asset.base64}`
          : asset.uri;
        setFotoUri(dataUri);
      }
    } finally {
      setFotoLoading(false);
    }
  }

  function handleFotoPress() {
    if (Platform.OS === "ios") {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          options: fotoUri
            ? ["Abbrechen", "Kamera", "Fotobibliothek", "Foto entfernen"]
            : ["Abbrechen", "Kamera", "Fotobibliothek"],
          cancelButtonIndex: 0,
          destructiveButtonIndex: fotoUri ? 3 : undefined,
        },
        (idx) => {
          if (idx === 1) pickFromCamera();
          else if (idx === 2) pickFromLibrary();
          else if (idx === 3 && fotoUri) setFotoUri(undefined);
        },
      );
    } else {
      const options = ["Kamera", "Fotobibliothek"];
      if (fotoUri) options.push("Foto entfernen");
      Alert.alert("Foto hinzufügen", undefined, [
        ...options.map((label, i) => ({
          text: label,
          style: (i === 2 ? "destructive" : "default") as "destructive" | "default",
          onPress: () => {
            if (i === 0) pickFromCamera();
            else if (i === 1) pickFromLibrary();
            else setFotoUri(undefined);
          },
        })),
        { text: "Abbrechen", style: "cancel" },
      ]);
    }
  }

  function handleSave() {
    const name = nameInput.trim();
    if (!name) return;
    if (editingId) {
      updateStueck(editingId, name, komponistInput.trim() || undefined, notizenInput.trim() || undefined, selectedFarbe, fotoUri);
    } else {
      addStueck(name, komponistInput.trim() || undefined, notizenInput.trim() || undefined, selectedFarbe, fotoUri);
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    closeModal();
  }

  function handleDelete(id: string, name: string) {
    const anzahl = eintraege.filter(e => e.stueckId === id).length;
    const hinweis = anzahl > 0 ? ` Es werden auch ${anzahl} Übungseinträge gelöscht.` : "";
    Alert.alert("Stück entfernen", `Möchtest du "${name}" löschen?${hinweis}`, [
      { text: "Abbrechen", style: "cancel" },
      {
        text: "Löschen",
        style: "destructive",
        onPress: () => {
          deleteStueck(id);
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        },
      },
    ]);
  }

  function getPracticeCount(id: string): number {
    return eintraege.filter(e => e.stueckId === id).length;
  }

  const topPad = Platform.OS === "web" ? insets.top + 67 : isLiquidGlassAvailable() ? insets.top : 0;
  const s = makeStyles(colors);

  return (
    <View style={[s.container, { paddingTop: topPad }]}>
      <FlatList
        data={stuecke}
        keyExtractor={item => item.id}
        contentContainerStyle={[s.list, { paddingBottom: Platform.OS === "web" ? insets.bottom + 134 : insets.bottom + 110 }]}
        ListHeaderComponent={
          stuecke.length > 0 ? (
            <Text style={s.listHeader}>
              {stuecke.length} {stuecke.length === 1 ? "Stück" : "Stücke"} im Repertoire
            </Text>
          ) : null
        }
        ListEmptyComponent={
          <View style={s.empty}>
            <Feather name="music" size={48} color={colors.mutedForeground} />
            <Text style={s.emptyTitle}>Noch keine Stücke</Text>
            <Text style={s.emptySub}>Füge die Stücke hinzu, die du auf dem Klavier üben möchtest</Text>
            <TouchableOpacity style={s.emptyBtn} onPress={openAddModal}>
              <Feather name="plus" size={16} color={colors.primaryForeground} />
              <Text style={s.emptyBtnText}>Erstes Stück hinzufügen</Text>
            </TouchableOpacity>
          </View>
        }
        renderItem={({ item }) => {
          const count = getPracticeCount(item.id);
          return (
            <TouchableOpacity style={s.card} onPress={() => openEditModal(item.id)} activeOpacity={0.75}>
              <View style={[s.colorStripe, { backgroundColor: item.farbe }]} />
              {item.foto ? (
                <Image source={{ uri: item.foto }} style={s.cardThumb} resizeMode="cover" />
              ) : (
                <View style={[s.iconBox, { backgroundColor: item.farbe + "22" }]}>
                  <Feather name="music" size={20} color={item.farbe} />
                </View>
              )}
              <View style={s.cardInfo}>
                <Text style={s.cardName}>{item.name}</Text>
                {item.komponist ? <Text style={s.cardKomp}>{item.komponist}</Text> : null}
                {item.notizen ? (
                  <Text style={s.cardNotizen} numberOfLines={2}>{item.notizen}</Text>
                ) : null}
                <Text style={s.cardCount}>
                  {count === 0 ? "Noch nicht eingeplant" : `${count} ${count === 1 ? "Einheit" : "Einheiten"} geplant`}
                </Text>
              </View>
              <View style={s.cardActions}>
                <TouchableOpacity style={s.editBtn} onPress={() => openEditModal(item.id)} hitSlop={6}>
                  <Feather name="edit-2" size={16} color={colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity style={s.trashBtn} onPress={() => handleDelete(item.id, item.name)} hitSlop={6}>
                  <Feather name="trash-2" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          );
        }}
      />

      <TouchableOpacity
        style={[s.fab, { bottom: Platform.OS === "web" ? insets.bottom + 104 : insets.bottom + 68 }]}
        onPress={openAddModal}
      >
        <Feather name="plus" size={28} color="#fff" />
      </TouchableOpacity>

      <Modal visible={showModal} transparent animationType="slide" onRequestClose={closeModal}>
        <Pressable style={s.overlay} onPress={closeModal}>
          <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            style={s.kav}
            keyboardVerticalOffset={0}
          >
            <Pressable
              style={[s.sheet, { maxHeight: "92%", paddingBottom: 0 }]}
              onPress={() => {}}
            >
              <View style={s.handle} />
              <Text style={s.sheetTitle}>{editingId ? "Stück bearbeiten" : "Neues Stück"}</Text>

              <ScrollView
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
              >
                <Text style={s.label}>Foto (optional)</Text>
                <TouchableOpacity
                  style={[s.fotoBtn, fotoUri ? s.fotoBtnFilled : null, { borderColor: selectedFarbe + "80" }]}
                  onPress={handleFotoPress}
                  activeOpacity={0.8}
                  disabled={fotoLoading}
                >
                  {fotoUri ? (
                    <>
                      <Image source={{ uri: fotoUri }} style={s.fotoPreview} resizeMode="cover" />
                      <View style={s.fotoOverlay}>
                        <Feather name="camera" size={18} color="#fff" />
                        <Text style={s.fotoOverlayText}>Ändern</Text>
                      </View>
                    </>
                  ) : (
                    <View style={s.fotoPlaceholder}>
                      <Feather name="camera" size={28} color={fotoLoading ? colors.primary : colors.mutedForeground} />
                      <Text style={[s.fotoPlaceholderText, { color: fotoLoading ? colors.primary : colors.mutedForeground }]}>
                        {fotoLoading ? "Wird geladen…" : "Foto aufnehmen oder auswählen"}
                      </Text>
                    </View>
                  )}
                </TouchableOpacity>

                <Text style={s.label}>Farbe</Text>
                <View style={s.colorPicker}>
                  {STUECK_FARBEN.map(farbe => (
                    <TouchableOpacity
                      key={farbe}
                      style={[
                        s.colorSwatch,
                        { backgroundColor: farbe },
                        selectedFarbe === farbe && s.colorSwatchSelected,
                      ]}
                      onPress={() => { setSelectedFarbe(farbe); Haptics.selectionAsync(); }}
                    >
                      {selectedFarbe === farbe && (
                        <Feather name="check" size={14} color="#fff" />
                      )}
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={s.label}>Titel *</Text>
                <TextInput
                  style={[s.input, { borderColor: selectedFarbe + "80" }]}
                  value={nameInput}
                  onChangeText={setNameInput}
                  placeholder="z. B. Mondscheinsonate"
                  placeholderTextColor={colors.mutedForeground}
                  autoFocus
                  returnKeyType="next"
                />

                <Text style={s.label}>Komponist (optional)</Text>
                <TextInput
                  style={s.input}
                  value={komponistInput}
                  onChangeText={setKomponistInput}
                  placeholder="z. B. Beethoven"
                  placeholderTextColor={colors.mutedForeground}
                  returnKeyType="next"
                />

                <Text style={s.label}>Was soll ich üben? (optional)</Text>
                <TextInput
                  style={[s.input, s.inputMulti]}
                  value={notizenInput}
                  onChangeText={setNotizenInput}
                  placeholder="z. B. Beide Hände getrennt üben, Takt 1–24 auswendig lernen…"
                  placeholderTextColor={colors.mutedForeground}
                  multiline
                  numberOfLines={3}
                  returnKeyType="done"
                  onSubmitEditing={handleSave}
                />

                <TouchableOpacity
                  style={[s.saveBtn, { backgroundColor: selectedFarbe }, !nameInput.trim() && s.saveBtnDis]}
                  onPress={handleSave}
                  disabled={!nameInput.trim()}
                >
                  <Text style={s.saveBtnText}>{editingId ? "Speichern" : "Hinzufügen"}</Text>
                </TouchableOpacity>
              </ScrollView>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    list: { paddingHorizontal: 16, paddingTop: 16 },
    listHeader: { fontSize: 13, fontFamily: "Inter_500Medium", color: colors.mutedForeground, marginBottom: 12 },
    empty: { alignItems: "center", paddingTop: 80, gap: 14 },
    emptyTitle: { fontSize: 20, fontFamily: "Inter_700Bold", color: colors.foreground },
    emptySub: { fontSize: 14, fontFamily: "Inter_400Regular", color: colors.mutedForeground, textAlign: "center", paddingHorizontal: 32, lineHeight: 20 },
    emptyBtn: { flexDirection: "row", alignItems: "center", backgroundColor: colors.primary, borderRadius: 12, paddingHorizontal: 20, paddingVertical: 12, gap: 8, marginTop: 8 },
    emptyBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.primaryForeground },
    card: { flexDirection: "row", alignItems: "center", backgroundColor: colors.card, borderRadius: 14, marginBottom: 10, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 4, elevation: 2 },
    colorStripe: { width: 5, alignSelf: "stretch" },
    iconBox: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center", marginLeft: 12 },
    cardThumb: { width: 52, height: 52, borderRadius: 8, marginLeft: 10 },
    cardInfo: { flex: 1, paddingVertical: 14, paddingLeft: 12, paddingRight: 6 },
    cardName: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    cardKomp: { fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    cardNotizen: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 3, lineHeight: 17 },
    cardCount: { fontSize: 12, fontFamily: "Inter_500Medium", color: colors.primary, marginTop: 4 },
    cardActions: { flexDirection: "column", alignItems: "center", gap: 4, paddingRight: 10, paddingVertical: 10 },
    editBtn: { padding: 8 },
    trashBtn: { padding: 8 },
    fab: { position: "absolute", right: 20, width: 56, height: 56, borderRadius: 28, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 8 },
    overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
    kav: { justifyContent: "flex-end" },
    sheet: { backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 },
    handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: "center", marginBottom: 20 },
    sheetTitle: { fontSize: 20, fontFamily: "Inter_700Bold", color: colors.foreground, marginBottom: 20 },
    label: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 8 },
    fotoBtn: { height: 130, borderRadius: 12, borderWidth: 1.5, borderStyle: "dashed", borderColor: colors.border, overflow: "hidden", marginBottom: 18, justifyContent: "center", alignItems: "center" },
    fotoBtnFilled: { borderStyle: "solid" },
    fotoPreview: { width: "100%", height: "100%" },
    fotoOverlay: { position: "absolute", bottom: 0, left: 0, right: 0, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: "rgba(0,0,0,0.45)", paddingVertical: 8 },
    fotoOverlayText: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#fff" },
    fotoPlaceholder: { alignItems: "center", gap: 8 },
    fotoPlaceholderText: { fontSize: 13, fontFamily: "Inter_400Regular" },
    colorPicker: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 18 },
    colorSwatch: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center" },
    colorSwatchSelected: { borderWidth: 3, borderColor: "rgba(0,0,0,0.25)", transform: [{ scale: 1.15 }] },
    input: { backgroundColor: colors.muted, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 16, fontFamily: "Inter_400Regular", color: colors.foreground, marginBottom: 16, borderWidth: 1, borderColor: colors.border },
    inputMulti: { height: 80, textAlignVertical: "top" },
    saveBtn: { borderRadius: 12, paddingVertical: 16, alignItems: "center", marginTop: 4 },
    saveBtnDis: { opacity: 0.45 },
    saveBtnText: { fontSize: 16, fontFamily: "Inter_700Bold", color: "#fff" },
  });
}
