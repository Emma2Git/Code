import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import React, { useEffect, useRef, useState } from "react";
import {
  FlatList,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

function formatClock(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) {
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds} Sek.`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return s > 0 ? `${m} Min. ${s} Sek.` : `${m} Min.`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm > 0 ? `${h} Std. ${rm} Min.` : `${h} Std.`;
}

function toDateString(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export default function StoppuhrScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { stuecke, sessions, addSession, deleteSession, getStueckById } = useApp();

  const [selectedIdx, setSelectedIdx] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [savedMessage, setSavedMessage] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const selectedStueck = stuecke[selectedIdx];

  function startPause() {
    if (isRunning) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setIsRunning(false);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    } else {
      if (!selectedStueck) return;
      setIsRunning(true);
      setSavedMessage(false);
      intervalRef.current = setInterval(() => setSeconds(s => s + 1), 1000);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }

  function handleSave() {
    if (!selectedStueck || seconds === 0) return;
    if (isRunning) { if (intervalRef.current) clearInterval(intervalRef.current); setIsRunning(false); }
    addSession(selectedStueck.id, seconds);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setSavedMessage(true);
    setSeconds(0);
    setTimeout(() => setSavedMessage(false), 2500);
  }

  function handleReset() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsRunning(false);
    setSeconds(0);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }

  const recentSessions = [...sessions].reverse().slice(0, 20);

  const topPad = Platform.OS === "web" ? insets.top + 67 : isLiquidGlassAvailable() ? insets.top : 0;
  const s = makeStyles(colors);

  return (
    <View style={[s.container, { paddingTop: topPad }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 40 + (Platform.OS === "web" ? 34 : 0) }}>

        {/* Piece Selector */}
        {stuecke.length === 0 ? (
          <View style={s.noStuecke}>
            <Feather name="music" size={32} color={colors.mutedForeground} />
            <Text style={s.noStueckeText}>Füge zuerst Stücke im Tab "Stücke" hinzu</Text>
          </View>
        ) : (
          <>
            <Text style={s.sectionLabel}>Stück auswählen</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chipRow}>
              {stuecke.map((st, idx) => (
                <TouchableOpacity
                  key={st.id}
                  style={[s.chip, selectedIdx === idx && { backgroundColor: st.farbe }]}
                  onPress={() => {
                    if (!isRunning) { setSelectedIdx(idx); Haptics.selectionAsync(); }
                  }}
                  disabled={isRunning}
                >
                  <View style={[s.chipDot, { backgroundColor: selectedIdx === idx ? "rgba(255,255,255,0.5)" : st.farbe }]} />
                  <Text style={[s.chipText, selectedIdx === idx && s.chipTextSel]} numberOfLines={1}>
                    {st.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Timer Display */}
            <View style={s.timerBox}>
              {selectedStueck && (
                <View style={[s.timerPiece, { borderColor: selectedStueck.farbe + "40" }]}>
                  <View style={[s.timerDot, { backgroundColor: selectedStueck.farbe }]} />
                  <Text style={s.timerPieceName}>{selectedStueck.name}</Text>
                  {selectedStueck.komponist ? <Text style={s.timerPieceKomp}> · {selectedStueck.komponist}</Text> : null}
                </View>
              )}
              <Text style={[s.timerText, isRunning && { color: selectedStueck?.farbe ?? colors.primary }]}>
                {formatClock(seconds)}
              </Text>
              {isRunning && <View style={[s.runningDot, { backgroundColor: selectedStueck?.farbe ?? colors.primary }]} />}
            </View>

            {/* Controls */}
            <View style={s.controls}>
              <TouchableOpacity
                style={[
                  s.mainBtn,
                  { backgroundColor: isRunning ? "#E74C3C" : (selectedStueck?.farbe ?? colors.primary) },
                ]}
                onPress={startPause}
              >
                <Feather name={isRunning ? "pause" : "play"} size={32} color="#fff" />
              </TouchableOpacity>
            </View>

            <View style={s.actionRow}>
              {seconds > 0 && !isRunning && (
                <TouchableOpacity style={s.actionBtn} onPress={handleSave}>
                  <Feather name="save" size={18} color={colors.primaryForeground} />
                  <Text style={s.actionBtnText}>Speichern</Text>
                </TouchableOpacity>
              )}
              {seconds > 0 && (
                <TouchableOpacity style={[s.actionBtn, s.actionBtnSecondary]} onPress={handleReset}>
                  <Feather name="rotate-ccw" size={18} color={colors.foreground} />
                  <Text style={[s.actionBtnText, { color: colors.foreground }]}>Zurücksetzen</Text>
                </TouchableOpacity>
              )}
            </View>

            {savedMessage && (
              <View style={s.savedBanner}>
                <Feather name="check-circle" size={18} color="#43A047" />
                <Text style={s.savedBannerText}>Session gespeichert!</Text>
              </View>
            )}
          </>
        )}

        {/* Recent Sessions */}
        {recentSessions.length > 0 && (
          <>
            <View style={s.historyHeader}>
              <Text style={s.historyTitle}>Letzte Sessions</Text>
            </View>
            {recentSessions.map(session => {
              const stueck = getStueckById(session.stueckId);
              if (!stueck) return null;
              const sessionDate = session.datum;
              const today = toDateString(new Date());
              const yesterday = (() => { const d = new Date(); d.setDate(d.getDate() - 1); return toDateString(d); })();
              const dateLabel = sessionDate === today ? "Heute" : sessionDate === yesterday ? "Gestern" : sessionDate;
              return (
                <View key={session.id} style={s.sessionCard}>
                  <View style={[s.sessionColor, { backgroundColor: stueck.farbe }]} />
                  <View style={s.sessionInfo}>
                    <Text style={s.sessionName}>{stueck.name}</Text>
                    <Text style={s.sessionDate}>{dateLabel}</Text>
                  </View>
                  <Text style={[s.sessionTime, { color: stueck.farbe }]}>{formatDuration(session.sekunden)}</Text>
                  <TouchableOpacity style={s.sessionDelete} onPress={() => { deleteSession(session.id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}>
                    <Feather name="x" size={16} color={colors.mutedForeground} />
                  </TouchableOpacity>
                </View>
              );
            })}
          </>
        )}
      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    noStuecke: { alignItems: "center", paddingTop: 60, gap: 12, paddingHorizontal: 32 },
    noStueckeText: { fontSize: 15, fontFamily: "Inter_400Regular", color: colors.mutedForeground, textAlign: "center" },
    sectionLabel: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.6, marginTop: 16, marginBottom: 10, paddingHorizontal: 20 },
    chipRow: { paddingHorizontal: 16, paddingBottom: 4, gap: 8 },
    chip: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.muted, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8 },
    chipDot: { width: 8, height: 8, borderRadius: 4 },
    chipText: { fontSize: 14, fontFamily: "Inter_500Medium", color: colors.foreground, maxWidth: 120 },
    chipTextSel: { color: "#fff", fontFamily: "Inter_600SemiBold" },
    timerBox: { alignItems: "center", paddingVertical: 32, paddingHorizontal: 20 },
    timerPiece: { flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 6, marginBottom: 24 },
    timerDot: { width: 8, height: 8, borderRadius: 4 },
    timerPieceName: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    timerPieceKomp: { fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground },
    timerText: { fontSize: 64, fontFamily: "Inter_700Bold", color: colors.foreground, letterSpacing: 2 },
    runningDot: { width: 8, height: 8, borderRadius: 4, marginTop: 12 },
    controls: { alignItems: "center", marginBottom: 16 },
    mainBtn: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.25, shadowRadius: 8, elevation: 6 },
    actionRow: { flexDirection: "row", justifyContent: "center", gap: 12, paddingHorizontal: 20, marginBottom: 8 },
    actionBtn: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.primary, borderRadius: 12, paddingHorizontal: 20, paddingVertical: 12, flex: 1, justifyContent: "center" },
    actionBtnSecondary: { backgroundColor: colors.muted },
    actionBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.primaryForeground },
    savedBanner: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#E8F5E9", borderRadius: 12, marginHorizontal: 20, paddingVertical: 12, marginBottom: 8 },
    savedBannerText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#43A047" },
    historyHeader: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 10, borderTopWidth: 1, borderTopColor: colors.border, marginTop: 8 },
    historyTitle: { fontSize: 15, fontFamily: "Inter_700Bold", color: colors.foreground },
    sessionCard: { flexDirection: "row", alignItems: "center", backgroundColor: colors.card, marginHorizontal: 16, marginBottom: 8, borderRadius: 12, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 1 },
    sessionColor: { width: 4, alignSelf: "stretch" },
    sessionInfo: { flex: 1, paddingVertical: 12, paddingLeft: 12 },
    sessionName: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    sessionDate: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    sessionTime: { fontSize: 14, fontFamily: "Inter_700Bold", paddingHorizontal: 10 },
    sessionDelete: { padding: 14 },
  });
}
