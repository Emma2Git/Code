import { useAuth, useUser } from "@clerk/expo";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import { useNavigation, useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

function toDateString(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

const WOCHENTAGE = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
const MONATE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 11) return "Guten Morgen";
  if (h < 17) return "Guten Tag";
  return "Guten Abend";
}

type ProfilModal = "password" | "email" | "email-verify" | null;

export default function HeuteScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const navigation = useNavigation();
  const { getEintraegeForDate, getStueckById, toggleErledigt, stuecke, erinnerungenAktiv, setErinnerungenAktiv } = useApp();
  const { signOut } = useAuth();
  const { user } = useUser();
  const [erinnerungenLoading, setErinnerungenLoading] = useState(false);

  const isNativeTabs = isLiquidGlassAvailable();

  // Profile sheet state
  const [showProfil, setShowProfil] = useState(false);
  const [profilModal, setProfilModal] = useState<ProfilModal>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [newPwConfirm, setNewPwConfirm] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [verifyCode, setVerifyCode] = useState("");
  const [pendingEmailId, setPendingEmailId] = useState<string | null>(null);

  const today = new Date();
  const todayStr = toDateString(today);
  const wochentag = WOCHENTAGE[today.getDay()] ?? "";
  const datum = `${today.getDate()}. ${MONATE[today.getMonth()]} ${today.getFullYear()}`;

  const eintraege = getEintraegeForDate(todayStr).sort((a, b) => {
    if (!a.uhrzeit && !b.uhrzeit) return 0;
    if (!a.uhrzeit) return 1;
    if (!b.uhrzeit) return -1;
    return a.uhrzeit.localeCompare(b.uhrzeit);
  });

  const erledigt = eintraege.filter(e => e.erledigt).length;
  const gesamt = eintraege.length;

  const primaryEmail = user?.primaryEmailAddress?.emailAddress ?? "";
  const initials = (user?.firstName?.[0] ?? user?.username?.[0] ?? primaryEmail[0] ?? "?").toUpperCase();

  // Set header right button for ClassicTabs
  useEffect(() => {
    if (!isNativeTabs) {
      navigation.setOptions({
        headerRight: () => (
          <TouchableOpacity
            onPress={() => setShowProfil(true)}
            style={{ marginRight: 16, padding: 4 }}
            hitSlop={8}
          >
            <View style={{
              width: 32, height: 32, borderRadius: 16,
              backgroundColor: colors.primary + "20",
              alignItems: "center", justifyContent: "center",
            }}>
              <Feather name="user" size={17} color={colors.primary} />
            </View>
          </TouchableOpacity>
        ),
      });
    }
  }, [isNativeTabs, colors.primary]);

  function closeProfilSheet() {
    setShowProfil(false);
    setProfilModal(null);
    setErrorMsg("");
    setCurrentPw(""); setNewPw(""); setNewPwConfirm("");
    setNewEmail(""); setVerifyCode(""); setPendingEmailId(null);
  }

  async function handleToggleErinnerungen(value: boolean) {
    setErinnerungenLoading(true);
    try {
      const result = await setErinnerungenAktiv(value);
      if (result === "denied") {
        Alert.alert("Erlaubnis nötig", "Bitte erlaube Benachrichtigungen, um Erinnerungen zu erhalten.");
      } else if (result === "blocked") {
        Alert.alert(
          "Benachrichtigungen deaktiviert",
          "Bitte aktiviere Benachrichtigungen für diese App in den Geräteeinstellungen.",
          Platform.OS !== "web"
            ? [
                { text: "Abbrechen", style: "cancel" },
                { text: "Einstellungen öffnen", onPress: () => { Linking.openSettings().catch(() => {}); } },
              ]
            : undefined,
        );
      }
    } finally {
      setErinnerungenLoading(false);
    }
  }

  async function handleSignOut() {
    Alert.alert("Abmelden", "Möchtest du dich wirklich abmelden?", [
      { text: "Abbrechen", style: "cancel" },
      {
        text: "Abmelden",
        style: "destructive",
        onPress: async () => {
          await signOut();
          router.replace("/(auth)/sign-in");
        },
      },
    ]);
  }

  async function handlePasswordChange() {
    setErrorMsg("");
    if (!newPw.trim()) { setErrorMsg("Bitte neues Passwort eingeben."); return; }
    if (newPw.length < 8) { setErrorMsg("Passwort muss mindestens 8 Zeichen lang sein."); return; }
    if (newPw !== newPwConfirm) { setErrorMsg("Die Passwörter stimmen nicht überein."); return; }
    setLoading(true);
    try {
      await user?.updatePassword({ currentPassword: currentPw, newPassword: newPw });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setProfilModal(null);
      setCurrentPw(""); setNewPw(""); setNewPwConfirm("");
      Alert.alert("Gespeichert", "Dein Passwort wurde erfolgreich geändert.");
    } catch (e: any) {
      setErrorMsg(e?.errors?.[0]?.message ?? e?.message ?? "Fehler beim Ändern des Passworts.");
    } finally {
      setLoading(false);
    }
  }

  async function handleEmailSubmit() {
    setErrorMsg("");
    if (!newEmail.trim() || !newEmail.includes("@")) { setErrorMsg("Bitte eine gültige E-Mail-Adresse eingeben."); return; }
    setLoading(true);
    try {
      const emailObj = await user?.createEmailAddress({ email: newEmail.trim() });
      if (!emailObj) throw new Error("Fehler.");
      await emailObj.prepareVerification({ strategy: "email_code" });
      setPendingEmailId(emailObj.id);
      setProfilModal("email-verify");
    } catch (e: any) {
      setErrorMsg(e?.errors?.[0]?.message ?? e?.message ?? "Fehler beim Senden des Codes.");
    } finally {
      setLoading(false);
    }
  }

  async function handleEmailVerify() {
    setErrorMsg("");
    if (!verifyCode.trim()) { setErrorMsg("Bitte den Bestätigungscode eingeben."); return; }
    setLoading(true);
    try {
      const emailObj = user?.emailAddresses.find(e => e.id === pendingEmailId);
      if (!emailObj) throw new Error("E-Mail nicht gefunden.");
      await emailObj.attemptVerification({ code: verifyCode.trim() });
      await user?.update({ primaryEmailAddressId: emailObj.id });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setProfilModal(null);
      setNewEmail(""); setVerifyCode(""); setPendingEmailId(null);
      Alert.alert("Gespeichert", "Deine E-Mail-Adresse wurde erfolgreich geändert.");
    } catch (e: any) {
      setErrorMsg(e?.errors?.[0]?.message ?? e?.message ?? "Ungültiger Code.");
    } finally {
      setLoading(false);
    }
  }

  const topPad = Platform.OS === "web" ? insets.top + 67 : isNativeTabs ? insets.top : 0;
  const s = makeStyles(colors);

  return (
    <View style={[s.container, { paddingTop: topPad }]}>
      {/* Header row — profile button shown only for NativeTabs (no built-in header) */}
      <View style={s.header}>
        <View style={s.headerText}>
          <Text style={s.greeting}>{getGreeting()}</Text>
          <Text style={s.wochentag}>{wochentag}</Text>
          <Text style={s.datum}>{datum}</Text>
        </View>
        {isNativeTabs && (
          <TouchableOpacity
            style={s.profileBtn}
            onPress={() => setShowProfil(true)}
            hitSlop={8}
          >
            <View style={s.profileBtnInner}>
              <Text style={s.profileBtnInitial}>{initials}</Text>
            </View>
          </TouchableOpacity>
        )}
      </View>

      {/* Progress */}
      {gesamt > 0 && (
        <View style={s.progressBox}>
          <View style={s.progressHeader}>
            <Text style={s.progressLabel}>Fortschritt</Text>
            <Text style={s.progressCount}>{erledigt}/{gesamt}</Text>
          </View>
          <View style={s.progressTrack}>
            <View style={[s.progressFill, { width: `${(erledigt / gesamt) * 100}%` as any }]} />
          </View>
        </View>
      )}

      {/* Practice list */}
      <FlatList
        data={eintraege}
        keyExtractor={item => item.id}
        contentContainerStyle={[
          s.list,
          { paddingBottom: insets.bottom + 100 + (Platform.OS === "web" ? 34 : 0) },
        ]}
        ListHeaderComponent={
          gesamt > 0 ? (
            <Text style={s.sectionTitle}>Übungsplan für heute</Text>
          ) : null
        }
        ListEmptyComponent={
          <View style={s.empty}>
            <View style={s.emptyIcon}>
              <Feather name="sun" size={36} color={colors.primary} />
            </View>
            <Text style={s.emptyTitle}>
              {stuecke.length === 0 ? "Willkommen!" : "Freier Tag!"}
            </Text>
            <Text style={s.emptySub}>
              {stuecke.length === 0
                ? "Füge im Tab \"Stücke\" deine ersten Klavierstücke hinzu"
                : "Für heute ist noch nichts eingeplant"}
            </Text>
            <TouchableOpacity
              style={s.emptyBtn}
              onPress={() => router.push("/kalender" as any)}
            >
              <Feather name="plus" size={16} color={colors.primaryForeground} />
              <Text style={s.emptyBtnText}>Im Kalender planen</Text>
            </TouchableOpacity>
          </View>
        }
        renderItem={({ item }) => {
          const stueck = getStueckById(item.stueckId);
          if (!stueck) return null;
          return (
            <TouchableOpacity
              style={[s.card, item.erledigt && s.cardDone]}
              onPress={() => {
                toggleErledigt(item.id);
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              activeOpacity={0.8}
            >
              <View style={[s.colorBar, { backgroundColor: stueck.farbe }]} />
              <View style={s.cardContent}>
                <View style={s.cardTop}>
                  <Text style={[s.cardName, item.erledigt && s.cardNameDone]}>
                    {stueck.name}
                  </Text>
                  {item.uhrzeit ? (
                    <View style={s.timeBadge}>
                      <Feather name="clock" size={11} color={colors.primary} />
                      <Text style={s.timeBadgeText}>{item.uhrzeit} Uhr</Text>
                    </View>
                  ) : null}
                </View>
                {stueck.komponist ? (
                  <Text style={s.cardKomp}>{stueck.komponist}</Text>
                ) : null}
                <View style={s.cardMeta}>
                  <Text style={s.cardDauer}>{item.dauerMinuten} Min.</Text>
                  {item.notizen ? (
                    <Text style={s.cardNotizen} numberOfLines={1}>{item.notizen}</Text>
                  ) : null}
                </View>
              </View>
              <View style={[s.checkbox, item.erledigt && { backgroundColor: stueck.farbe, borderColor: stueck.farbe }]}>
                {item.erledigt && <Feather name="check" size={14} color="#fff" />}
              </View>
            </TouchableOpacity>
          );
        }}
      />

      {/* ── Profil Sheet ── */}
      <Modal visible={showProfil && profilModal === null} transparent animationType="slide" onRequestClose={closeProfilSheet}>
        <Pressable style={s.overlay} onPress={closeProfilSheet}>
          <Pressable style={[s.sheet, { paddingBottom: insets.bottom + 32 }]} onPress={() => {}}>
            <View style={s.handle} />

            {/* Avatar */}
            <View style={s.avatarRow}>
              <View style={s.avatar}>
                <Text style={s.avatarText}>{initials}</Text>
              </View>
              <View style={{ flex: 1 }}>
                {(user?.firstName || user?.lastName) && (
                  <Text style={s.displayName}>{[user?.firstName, user?.lastName].filter(Boolean).join(" ")}</Text>
                )}
                <Text style={s.emailDisplay}>{primaryEmail}</Text>
              </View>
            </View>

            <Text style={s.sectionLabel}>Account</Text>
            <View style={s.menuCard}>
              <TouchableOpacity style={s.menuRow} onPress={() => { setProfilModal("email"); setErrorMsg(""); }}>
                <View style={s.menuIcon}>
                  <Feather name="mail" size={17} color={colors.primary} />
                </View>
                <View style={s.menuRowText}>
                  <Text style={s.menuRowTitle}>E-Mail-Adresse ändern</Text>
                  <Text style={s.menuRowSub} numberOfLines={1}>{primaryEmail}</Text>
                </View>
                <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
              </TouchableOpacity>
              <View style={s.divider} />
              <TouchableOpacity style={s.menuRow} onPress={() => { setProfilModal("password"); setErrorMsg(""); }}>
                <View style={s.menuIcon}>
                  <Feather name="lock" size={17} color={colors.primary} />
                </View>
                <View style={s.menuRowText}>
                  <Text style={s.menuRowTitle}>Passwort ändern</Text>
                </View>
                <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>

            <Text style={s.sectionLabel}>Erinnerungen</Text>
            <View style={s.menuCard}>
              <View style={s.menuRow}>
                <View style={s.menuIcon}>
                  <Feather name="bell" size={17} color={colors.primary} />
                </View>
                <View style={s.menuRowText}>
                  <Text style={s.menuRowTitle}>Übungserinnerungen</Text>
                  <Text style={s.menuRowSub} numberOfLines={2}>Benachrichtigung zur geplanten Uhrzeit</Text>
                </View>
                {erinnerungenLoading ? (
                  <ActivityIndicator color={colors.primary} />
                ) : (
                  <Switch
                    value={erinnerungenAktiv}
                    onValueChange={handleToggleErinnerungen}
                    trackColor={{ true: colors.primary }}
                  />
                )}
              </View>
            </View>

            <Text style={[s.sectionLabel, { marginTop: 4 }]}>Sitzung</Text>
            <View style={s.menuCard}>
              <TouchableOpacity style={s.menuRow} onPress={handleSignOut}>
                <View style={[s.menuIcon, { backgroundColor: "#FEE2E2" }]}>
                  <Feather name="log-out" size={17} color="#DC2626" />
                </View>
                <Text style={[s.menuRowTitle, { color: "#DC2626" }]}>Abmelden</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Password Modal */}
      <Modal visible={profilModal === "password"} transparent animationType="slide" onRequestClose={() => setProfilModal(null)}>
        <Pressable style={s.overlay} onPress={() => setProfilModal(null)}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={s.kav}>
            <Pressable style={[s.sheet, { paddingBottom: insets.bottom + 24 }]} onPress={() => {}}>
              <View style={s.handle} />
              <Text style={s.sheetTitle}>Passwort ändern</Text>

              <Text style={s.label}>Aktuelles Passwort</Text>
              <TextInput style={s.input} value={currentPw} onChangeText={setCurrentPw}
                placeholder="Aktuelles Passwort" placeholderTextColor={colors.mutedForeground}
                secureTextEntry autoFocus />

              <Text style={s.label}>Neues Passwort</Text>
              <TextInput style={s.input} value={newPw} onChangeText={setNewPw}
                placeholder="Mindestens 8 Zeichen" placeholderTextColor={colors.mutedForeground}
                secureTextEntry />

              <Text style={s.label}>Neues Passwort bestätigen</Text>
              <TextInput style={s.input} value={newPwConfirm} onChangeText={setNewPwConfirm}
                placeholder="Passwort wiederholen" placeholderTextColor={colors.mutedForeground}
                secureTextEntry />

              {errorMsg ? <Text style={s.error}>{errorMsg}</Text> : null}

              <TouchableOpacity style={[s.saveBtn, (loading || !currentPw || !newPw) && s.saveBtnDis]}
                onPress={handlePasswordChange} disabled={loading || !currentPw || !newPw}>
                {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.saveBtnText}>Speichern</Text>}
              </TouchableOpacity>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>

      {/* Email Step 1 */}
      <Modal visible={profilModal === "email"} transparent animationType="slide" onRequestClose={() => setProfilModal(null)}>
        <Pressable style={s.overlay} onPress={() => setProfilModal(null)}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={s.kav}>
            <Pressable style={[s.sheet, { paddingBottom: insets.bottom + 24 }]} onPress={() => {}}>
              <View style={s.handle} />
              <Text style={s.sheetTitle}>E-Mail-Adresse ändern</Text>
              <Text style={s.sheetSub}>Wir senden dir einen Bestätigungscode an die neue Adresse.</Text>

              <Text style={s.label}>Neue E-Mail-Adresse</Text>
              <TextInput style={s.input} value={newEmail} onChangeText={setNewEmail}
                placeholder="neue@email.de" placeholderTextColor={colors.mutedForeground}
                keyboardType="email-address" autoCapitalize="none" autoFocus />

              {errorMsg ? <Text style={s.error}>{errorMsg}</Text> : null}

              <TouchableOpacity style={[s.saveBtn, (loading || !newEmail) && s.saveBtnDis]}
                onPress={handleEmailSubmit} disabled={loading || !newEmail}>
                {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.saveBtnText}>Code senden</Text>}
              </TouchableOpacity>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>

      {/* Email Step 2 */}
      <Modal visible={profilModal === "email-verify"} transparent animationType="slide" onRequestClose={() => setProfilModal(null)}>
        <Pressable style={s.overlay} onPress={() => setProfilModal(null)}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={s.kav}>
            <Pressable style={[s.sheet, { paddingBottom: insets.bottom + 24 }]} onPress={() => {}}>
              <View style={s.handle} />
              <Text style={s.sheetTitle}>E-Mail bestätigen</Text>
              <Text style={s.sheetSub}>Wir haben einen 6-stelligen Code an {newEmail} gesendet.</Text>

              <Text style={s.label}>Bestätigungscode</Text>
              <TextInput style={[s.input, s.codeInput]} value={verifyCode} onChangeText={setVerifyCode}
                placeholder="123456" placeholderTextColor={colors.mutedForeground}
                keyboardType="numeric" maxLength={6} autoFocus />

              {errorMsg ? <Text style={s.error}>{errorMsg}</Text> : null}

              <TouchableOpacity style={[s.saveBtn, (loading || !verifyCode) && s.saveBtnDis]}
                onPress={handleEmailVerify} disabled={loading || !verifyCode}>
                {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.saveBtnText}>Bestätigen</Text>}
              </TouchableOpacity>

              <TouchableOpacity style={s.backLink} onPress={() => { setProfilModal("email"); setErrorMsg(""); setVerifyCode(""); }}>
                <Text style={s.backLinkText}>Zurück</Text>
              </TouchableOpacity>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    header: { flexDirection: "row", alignItems: "flex-start", paddingHorizontal: 20, paddingTop: 20, paddingBottom: 16 },
    headerText: { flex: 1 },
    greeting: { fontSize: 14, fontFamily: "Inter_500Medium", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 1 },
    wochentag: { fontSize: 30, fontFamily: "Inter_700Bold", color: colors.foreground, marginTop: 4 },
    datum: { fontSize: 16, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    profileBtn: { marginTop: 6 },
    profileBtnInner: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", shadowColor: colors.primary, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4, elevation: 4 },
    profileBtnInitial: { fontSize: 16, fontFamily: "Inter_700Bold", color: "#fff" },
    progressBox: { marginHorizontal: 20, marginBottom: 16, backgroundColor: colors.card, borderRadius: 14, padding: 14, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
    progressHeader: { flexDirection: "row", justifyContent: "space-between", marginBottom: 8 },
    progressLabel: { fontSize: 13, fontFamily: "Inter_500Medium", color: colors.mutedForeground },
    progressCount: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.primary },
    progressTrack: { height: 6, backgroundColor: colors.muted, borderRadius: 3, overflow: "hidden" },
    progressFill: { height: "100%", backgroundColor: colors.primary, borderRadius: 3 },
    list: { paddingHorizontal: 20, paddingTop: 4 },
    sectionTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 10 },
    empty: { alignItems: "center", paddingTop: 48, gap: 12 },
    emptyIcon: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.muted, alignItems: "center", justifyContent: "center" },
    emptyTitle: { fontSize: 22, fontFamily: "Inter_700Bold", color: colors.foreground },
    emptySub: { fontSize: 14, fontFamily: "Inter_400Regular", color: colors.mutedForeground, textAlign: "center", paddingHorizontal: 32, lineHeight: 20 },
    emptyBtn: { flexDirection: "row", alignItems: "center", backgroundColor: colors.primary, borderRadius: 12, paddingHorizontal: 20, paddingVertical: 12, gap: 8, marginTop: 8 },
    emptyBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.primaryForeground },
    card: { flexDirection: "row", alignItems: "center", backgroundColor: colors.card, borderRadius: 14, marginBottom: 10, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 4, elevation: 2 },
    cardDone: { opacity: 0.65 },
    colorBar: { width: 5, alignSelf: "stretch" },
    cardContent: { flex: 1, paddingVertical: 14, paddingLeft: 14, paddingRight: 8 },
    cardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
    cardName: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: colors.foreground, flex: 1 },
    cardNameDone: { textDecorationLine: "line-through", color: colors.mutedForeground },
    timeBadge: { flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: colors.muted, borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3 },
    timeBadgeText: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: colors.primary },
    cardKomp: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    cardMeta: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 4 },
    cardDauer: { fontSize: 12, fontFamily: "Inter_500Medium", color: colors.primary },
    cardNotizen: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, flex: 1 },
    checkbox: { width: 26, height: 26, borderRadius: 13, borderWidth: 2, borderColor: colors.border, alignItems: "center", justifyContent: "center", marginRight: 14 },
    // Profile sheet
    overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
    kav: { justifyContent: "flex-end" },
    sheet: { backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 },
    handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: "center", marginBottom: 20 },
    avatarRow: { flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 24 },
    avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
    avatarText: { fontSize: 22, fontFamily: "Inter_700Bold", color: "#fff" },
    displayName: { fontSize: 17, fontFamily: "Inter_700Bold", color: colors.foreground },
    emailDisplay: { fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    sectionLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 8, marginLeft: 2 },
    menuCard: { backgroundColor: colors.card, borderRadius: 14, marginBottom: 16, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3, elevation: 2 },
    menuRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 14, paddingVertical: 13, gap: 12 },
    menuIcon: { width: 34, height: 34, borderRadius: 9, backgroundColor: colors.primary + "18", alignItems: "center", justifyContent: "center" },
    menuRowText: { flex: 1 },
    menuRowTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    menuRowSub: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 1 },
    divider: { height: 1, backgroundColor: colors.border, marginHorizontal: 14 },
    // Sub-modals
    sheetTitle: { fontSize: 20, fontFamily: "Inter_700Bold", color: colors.foreground, marginBottom: 6 },
    sheetSub: { fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginBottom: 20, lineHeight: 19 },
    label: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 8 },
    input: { backgroundColor: colors.muted, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 16, fontFamily: "Inter_400Regular", color: colors.foreground, marginBottom: 16, borderWidth: 1, borderColor: colors.border },
    codeInput: { fontSize: 24, fontFamily: "Inter_700Bold", textAlign: "center", letterSpacing: 8 },
    error: { fontSize: 13, fontFamily: "Inter_400Regular", color: "#DC2626", marginBottom: 12, marginTop: -6 },
    saveBtn: { backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 16, alignItems: "center", marginTop: 4 },
    saveBtnDis: { opacity: 0.45 },
    saveBtnText: { fontSize: 16, fontFamily: "Inter_700Bold", color: colors.primaryForeground },
    backLink: { alignItems: "center", paddingVertical: 12 },
    backLinkText: { fontSize: 14, fontFamily: "Inter_500Medium", color: colors.primary },
  });
}
