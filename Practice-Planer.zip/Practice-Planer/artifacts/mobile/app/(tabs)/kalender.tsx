import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import React, { useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Termin, useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const WOCHENTAGE_KURZ = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const MONATE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
const MONATE_KURZ = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];

function toDateString(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function getMonthGrid(year: number, month: number): (Date | null)[] {
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const firstDow = firstDay.getDay();
  const startOffset = firstDow === 0 ? 6 : firstDow - 1;
  const grid: (Date | null)[] = [];
  for (let i = 0; i < startOffset; i++) grid.push(null);
  for (let d = 1; d <= lastDay.getDate(); d++) grid.push(new Date(year, month, d));
  while (grid.length % 7 !== 0) grid.push(null);
  return grid;
}

const TERMIN_FARBEN = [
  '#6366F1', '#E74C3C', '#E91E8C', '#9C27B0',
  '#1E88E5', '#00ACC1', '#43A047', '#F9A825',
  '#FB8C00', '#795548',
];
const TERMIN_FARBE_DEFAULT = '#6366F1';

type AddMode = "uebung" | "termin";

export default function KalenderScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    stuecke, addEintrag, updateEintrag, deleteEintrag, toggleErledigt,
    getEintraegeForDate, getStueckById,
    addTermin, updateTermin, deleteTermin, getTermineForDate,
  } = useApp();

  const today = new Date();
  const todayStr = toDateString(today);

  const [displayYear, setDisplayYear] = useState(today.getFullYear());
  const [displayMonth, setDisplayMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState(todayStr);

  // Mode selection
  const [addMode, setAddMode] = useState<AddMode>("uebung");
  const [showModeMenu, setShowModeMenu] = useState(false);

  // Übung modal
  const [showUebungModal, setShowUebungModal] = useState(false);
  const [editingEintragId, setEditingEintragId] = useState<string | null>(null);
  const [selectedStueckId, setSelectedStueckId] = useState("");
  const [dauerInput, setDauerInput] = useState("30");
  const [notizenUebungInput, setNotizenUebungInput] = useState("");
  const [stundenInput, setStundenInput] = useState("");
  const [minutenInput, setMinutenInput] = useState("");

  // Termin modal
  const [showTerminModal, setShowTerminModal] = useState(false);
  const [editingTerminId, setEditingTerminId] = useState<string | null>(null);
  const [terminNameInput, setTerminNameInput] = useState("");
  const [terminStundenInput, setTerminStundenInput] = useState("");
  const [terminMinutenInput, setTerminMinutenInput] = useState("");
  const [notizenTerminInput, setNotizenTerminInput] = useState("");
  const [terminFarbe, setTerminFarbe] = useState(TERMIN_FARBE_DEFAULT);
  const [terminEndTagInput, setTerminEndTagInput] = useState("");
  const [terminEndMonatInput, setTerminEndMonatInput] = useState("");
  const [terminEndJahrInput, setTerminEndJahrInput] = useState("");

  function prevMonth() {
    if (displayMonth === 0) { setDisplayMonth(11); setDisplayYear(y => y - 1); }
    else setDisplayMonth(m => m - 1);
  }
  function nextMonth() {
    if (displayMonth === 11) { setDisplayMonth(0); setDisplayYear(y => y + 1); }
    else setDisplayMonth(m => m + 1);
  }

  // --- Übung handlers ---
  function openAddUebung() {
    if (stuecke.length === 0) return;
    setEditingEintragId(null);
    setSelectedStueckId(stuecke[0]?.id ?? "");
    setDauerInput("30");
    setNotizenUebungInput("");
    setStundenInput("");
    setMinutenInput("");
    setShowUebungModal(true);
  }

  function openEditUebung(eintragId: string) {
    const alle = getEintraegeForDate(selectedDate);
    const eintrag = alle.find(e => e.id === eintragId);
    if (!eintrag) return;
    setEditingEintragId(eintragId);
    setSelectedStueckId(eintrag.stueckId);
    setDauerInput(String(eintrag.dauerMinuten));
    setNotizenUebungInput(eintrag.notizen ?? "");
    if (eintrag.uhrzeit) {
      const [h, m] = eintrag.uhrzeit.split(":");
      setStundenInput(h ?? "");
      setMinutenInput(m ?? "");
    } else {
      setStundenInput(""); setMinutenInput("");
    }
    setShowUebungModal(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  function handleSaveUebung() {
    if (!selectedStueckId) return;
    const dauer = parseInt(dauerInput, 10);
    if (isNaN(dauer) || dauer <= 0) return;
    let uhrzeit: string | undefined;
    if (stundenInput || minutenInput) {
      uhrzeit = `${stundenInput.padStart(2, "0")}:${minutenInput.padStart(2, "0")}`;
    }
    if (editingEintragId) {
      updateEintrag(editingEintragId, dauer, notizenUebungInput.trim() || undefined, uhrzeit);
    } else {
      addEintrag(selectedDate, selectedStueckId, dauer, notizenUebungInput.trim() || undefined, uhrzeit);
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowUebungModal(false);
    setEditingEintragId(null);
  }

  // --- Termin handlers ---
  function openAddTermin() {
    setEditingTerminId(null);
    setTerminNameInput("");
    setTerminStundenInput("");
    setTerminMinutenInput("");
    setNotizenTerminInput("");
    setTerminFarbe(TERMIN_FARBE_DEFAULT);
    setTerminEndTagInput("");
    setTerminEndMonatInput("");
    setTerminEndJahrInput("");
    setShowTerminModal(true);
  }

  function openEditTermin(termin: Termin) {
    setEditingTerminId(termin.id);
    setTerminNameInput(termin.name);
    setNotizenTerminInput(termin.notizen ?? "");
    setTerminFarbe(termin.farbe ?? TERMIN_FARBE_DEFAULT);
    if (termin.uhrzeit) {
      const [h, m] = termin.uhrzeit.split(":");
      setTerminStundenInput(h ?? "");
      setTerminMinutenInput(m ?? "");
    } else {
      setTerminStundenInput(""); setTerminMinutenInput("");
    }
    if (termin.endDatum) {
      const [jj, mm, tt] = termin.endDatum.split("-");
      setTerminEndTagInput(String(parseInt(tt ?? "0")));
      setTerminEndMonatInput(String(parseInt(mm ?? "0")));
      setTerminEndJahrInput(jj ?? "");
    } else {
      setTerminEndTagInput(""); setTerminEndMonatInput(""); setTerminEndJahrInput("");
    }
    setShowTerminModal(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  function handleSaveTermin() {
    const name = terminNameInput.trim();
    if (!name) return;
    let uhrzeit: string | undefined;
    if (terminStundenInput || terminMinutenInput) {
      uhrzeit = `${terminStundenInput.padStart(2, "0")}:${terminMinutenInput.padStart(2, "0")}`;
    }
    let endDatum: string | undefined;
    if (terminEndTagInput && terminEndMonatInput && terminEndJahrInput) {
      const ed = `${terminEndJahrInput.padStart(4, "0")}-${terminEndMonatInput.padStart(2, "0")}-${terminEndTagInput.padStart(2, "0")}`;
      if (ed > selectedDate) endDatum = ed;
    }
    if (editingTerminId) {
      updateTermin(editingTerminId, name, uhrzeit, notizenTerminInput.trim() || undefined, endDatum, terminFarbe);
    } else {
      addTermin(selectedDate, name, uhrzeit, notizenTerminInput.trim() || undefined, endDatum, terminFarbe);
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowTerminModal(false);
    setEditingTerminId(null);
  }

  function handleOpenAdd() {
    if (addMode === "uebung") openAddUebung();
    else openAddTermin();
  }

  // --- Build sorted day list ---
  const selectedEintraege = getEintraegeForDate(selectedDate);
  const selectedTermine = getTermineForDate(selectedDate);

  type DayItem =
    | { type: "uebung"; id: string; uhrzeit?: string }
    | { type: "termin"; id: string; uhrzeit?: string };

  const dayItems: DayItem[] = [
    ...selectedEintraege.map(e => ({ type: "uebung" as const, id: e.id, uhrzeit: e.uhrzeit })),
    ...selectedTermine.map(t => ({ type: "termin" as const, id: t.id, uhrzeit: t.uhrzeit })),
  ].sort((a, b) => {
    if (!a.uhrzeit && !b.uhrzeit) return 0;
    if (!a.uhrzeit) return 1;
    if (!b.uhrzeit) return -1;
    return a.uhrzeit.localeCompare(b.uhrzeit);
  });

  const grid = getMonthGrid(displayYear, displayMonth);
  const [selectedDay] = selectedDate.split("-").map(Number).slice(2);

  const topPad = Platform.OS === "web" ? insets.top + 67 : isLiquidGlassAvailable() ? insets.top : 0;
  const s = makeStyles(colors);

  const hasItems = stuecke.length > 0 || selectedTermine.length > 0;

  return (
    <View style={[s.container, { paddingTop: topPad }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 100 + (Platform.OS === "web" ? 34 : 0) }}>
        {/* Month Navigation */}
        <View style={s.monthNav}>
          <TouchableOpacity style={s.navBtn} onPress={prevMonth}>
            <Feather name="chevron-left" size={24} color={colors.foreground} />
          </TouchableOpacity>
          <Text style={s.monthTitle}>{MONATE[displayMonth]} {displayYear}</Text>
          <TouchableOpacity style={s.navBtn} onPress={nextMonth}>
            <Feather name="chevron-right" size={24} color={colors.foreground} />
          </TouchableOpacity>
        </View>

        {/* Day Header Row */}
        <View style={s.dayHeader}>
          {WOCHENTAGE_KURZ.map(d => (
            <Text key={d} style={s.dayHeaderText}>{d}</Text>
          ))}
        </View>

        {/* Calendar Grid */}
        <View style={s.grid}>
          {Array.from({ length: grid.length / 7 }, (_, rowIdx) => (
            <View key={rowIdx} style={s.gridRow}>
              {grid.slice(rowIdx * 7, rowIdx * 7 + 7).map((date, colIdx) => {
                if (!date) return <View key={`empty-${rowIdx}-${colIdx}`} style={s.dayCell} />;
                const dateStr = toDateString(date);
                const isSelected = dateStr === selectedDate;
                const isToday = dateStr === todayStr;
                const dayEintraege = getEintraegeForDate(dateStr);
                const dayTermine = getTermineForDate(dateStr);
                const hasUebung = dayEintraege.length > 0;
                const hasTermin = dayTermine.length > 0;
                const allDone = hasUebung && dayEintraege.every(e => e.erledigt);
                return (
                  <TouchableOpacity
                    key={dateStr}
                    style={[s.dayCell, isSelected && s.dayCellSelected, isToday && !isSelected && s.dayCellToday]}
                    onPress={() => { setSelectedDate(dateStr); Haptics.selectionAsync(); }}
                  >
                    <Text style={[s.dayCellText, isSelected && s.dayCellTextSelected, isToday && !isSelected && s.dayCellTextToday]}>
                      {date.getDate()}
                    </Text>
                    {(hasUebung || hasTermin) && (
                      <View style={s.dotRow}>
                        {hasUebung && <View style={[s.dot, isSelected ? s.dotSelected : allDone ? s.dotDone : null]} />}
                        {dayTermine.slice(0, 3).map(t => (
                          <View key={t.id} style={[s.dot, isSelected ? s.dotSelected : { backgroundColor: t.farbe ?? TERMIN_FARBE_DEFAULT }]} />
                        ))}
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </View>

        {/* Selected Day Detail */}
        <View style={s.detailSection}>
          <View style={s.detailHeader}>
            <Text style={s.detailTitle}>
              {selectedDay}. {MONATE_KURZ[parseInt(selectedDate.split("-")[1] ?? "1") - 1]} {selectedDate.split("-")[0]}
            </Text>

            {/* Split add button */}
            <View style={s.splitBtn}>
              <TouchableOpacity
                style={[s.splitMain, (!hasItems && addMode === "uebung" && stuecke.length === 0) && { opacity: 0.4 }]}
                onPress={handleOpenAdd}
                disabled={addMode === "uebung" && stuecke.length === 0}
              >
                <Feather name="plus" size={15} color={colors.primaryForeground} />
                <Text style={s.splitMainText}>{addMode === "uebung" ? "Übung" : "Termin"}</Text>
              </TouchableOpacity>
              <View style={s.splitDivider} />
              <TouchableOpacity style={s.splitArrow} onPress={() => setShowModeMenu(true)}>
                <Feather name="chevron-down" size={13} color={colors.primaryForeground} />
              </TouchableOpacity>
            </View>
          </View>

          {dayItems.length === 0 ? (
            <View style={s.emptyDetail}>
              <Text style={s.emptyDetailText}>
                {stuecke.length === 0
                  ? 'Füge zuerst Stücke im Tab "Stücke" hinzu oder erstelle einen Termin'
                  : "Kein Übungsplan für diesen Tag"}
              </Text>
            </View>
          ) : (
            dayItems.map(item => {
              if (item.type === "uebung") {
                const eintrag = selectedEintraege.find(e => e.id === item.id);
                if (!eintrag) return null;
                const stueck = getStueckById(eintrag.stueckId);
                if (!stueck) return null;
                return (
                  <View key={item.id} style={s.eintragCard}>
                    <View style={[s.eintragColorBar, { backgroundColor: stueck.farbe }]} />
                    <TouchableOpacity
                      style={[s.eintragCheck, eintrag.erledigt && { backgroundColor: stueck.farbe, borderColor: stueck.farbe }]}
                      onPress={() => { toggleErledigt(eintrag.id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                    >
                      {eintrag.erledigt && <Feather name="check" size={13} color="#fff" />}
                    </TouchableOpacity>
                    <View style={s.eintragInfo}>
                      <View style={s.eintragTop}>
                        <Text style={[s.eintragName, eintrag.erledigt && s.eintragNameDone]}>{stueck.name}</Text>
                        {eintrag.uhrzeit ? (
                          <View style={s.timeBadge}>
                            <Feather name="clock" size={10} color={colors.primary} />
                            <Text style={s.timeBadgeText}>{eintrag.uhrzeit} Uhr</Text>
                          </View>
                        ) : null}
                      </View>
                      {stueck.komponist ? <Text style={s.eintragKomp}>{stueck.komponist}</Text> : null}
                      <Text style={s.eintragDauer}>{eintrag.dauerMinuten} Min.</Text>
                      {eintrag.notizen ? <Text style={s.eintragNotizen} numberOfLines={2}>{eintrag.notizen}</Text> : null}
                    </View>
                    <View style={s.cardActions}>
                      <TouchableOpacity style={s.actionBtn} onPress={() => openEditUebung(eintrag.id)} hitSlop={6}>
                        <Feather name="edit-2" size={15} color={colors.primary} />
                      </TouchableOpacity>
                      <TouchableOpacity style={s.actionBtn} onPress={() => { deleteEintrag(eintrag.id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }} hitSlop={6}>
                        <Feather name="trash-2" size={15} color={colors.mutedForeground} />
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              } else {
                const termin = selectedTermine.find(t => t.id === item.id);
                if (!termin) return null;
                const tc = termin.farbe ?? TERMIN_FARBE_DEFAULT;
                return (
                  <View key={item.id} style={s.terminCard}>
                    <View style={[s.eintragColorBar, { backgroundColor: tc }]} />
                    <View style={[s.terminIcon, { backgroundColor: tc + "18" }]}>
                      <Feather name="calendar" size={16} color={tc} />
                    </View>
                    <View style={s.eintragInfo}>
                      <View style={s.eintragTop}>
                        <Text style={s.terminName}>{termin.name}</Text>
                        {termin.uhrzeit ? (
                          <View style={[s.timeBadge, { backgroundColor: tc + "15" }]}>
                            <Feather name="clock" size={10} color={tc} />
                            <Text style={[s.timeBadgeText, { color: tc }]}>{termin.uhrzeit} Uhr</Text>
                          </View>
                        ) : null}
                      </View>
                      {termin.endDatum ? (
                        <Text style={[s.eintragKomp, { color: tc }]}>bis {termin.endDatum.split("-").reverse().join(".")}</Text>
                      ) : null}
                      {termin.notizen ? <Text style={s.eintragNotizen} numberOfLines={2}>{termin.notizen}</Text> : null}
                    </View>
                    <View style={s.cardActions}>
                      <TouchableOpacity style={s.actionBtn} onPress={() => openEditTermin(termin)} hitSlop={6}>
                        <Feather name="edit-2" size={15} color={tc} />
                      </TouchableOpacity>
                      <TouchableOpacity style={s.actionBtn} onPress={() => {
                        Alert.alert("Termin löschen", `"${termin.name}" löschen?`, [
                          { text: "Abbrechen", style: "cancel" },
                          { text: "Löschen", style: "destructive", onPress: () => { deleteTermin(termin.id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); } },
                        ]);
                      }} hitSlop={6}>
                        <Feather name="trash-2" size={15} color={colors.mutedForeground} />
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              }
            })
          )}
        </View>
      </ScrollView>

      {/* Mode picker dropdown */}
      <Modal visible={showModeMenu} transparent animationType="fade" onRequestClose={() => setShowModeMenu(false)}>
        <Pressable style={s.modeOverlay} onPress={() => setShowModeMenu(false)}>
          <View style={s.modeMenu}>
            <TouchableOpacity
              style={[s.modeOption, addMode === "uebung" && s.modeOptionActive]}
              onPress={() => { setAddMode("uebung"); setShowModeMenu(false); Haptics.selectionAsync(); }}
            >
              <Feather name="music" size={16} color={addMode === "uebung" ? colors.primary : colors.foreground} />
              <Text style={[s.modeOptionText, addMode === "uebung" && { color: colors.primary }]}>Übung</Text>
              {addMode === "uebung" && <Feather name="check" size={14} color={colors.primary} />}
            </TouchableOpacity>
            <View style={s.modeDivider} />
            <TouchableOpacity
              style={[s.modeOption, addMode === "termin" && s.modeOptionActive]}
              onPress={() => { setAddMode("termin"); setShowModeMenu(false); Haptics.selectionAsync(); }}
            >
              <Feather name="calendar" size={16} color={addMode === "termin" ? colors.primary : colors.foreground} />
              <Text style={[s.modeOptionText, addMode === "termin" && { color: colors.primary }]}>Termin</Text>
              {addMode === "termin" && <Feather name="check" size={14} color={colors.primary} />}
            </TouchableOpacity>
          </View>
        </Pressable>
      </Modal>

      {/* Übung Modal */}
      <Modal visible={showUebungModal} transparent animationType="slide" onRequestClose={() => { setShowUebungModal(false); setEditingEintragId(null); }}>
        <Pressable style={s.overlay} onPress={() => { setShowUebungModal(false); setEditingEintragId(null); }}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={s.kav}>
            <Pressable style={[s.sheet, { paddingBottom: insets.bottom + 24 }]} onPress={() => {}}>
              <View style={s.handle} />
              <Text style={s.sheetTitle}>{editingEintragId ? "Übung bearbeiten" : "Übung hinzufügen"}</Text>

              <Text style={s.label}>Stück auswählen</Text>
              <ScrollView style={s.stueckPicker} showsVerticalScrollIndicator={false}>
                {stuecke.map((st, idx) => (
                  <TouchableOpacity
                    key={st.id}
                    style={[
                      s.stueckRow, idx === stuecke.length - 1 && s.stueckRowLast,
                      selectedStueckId === st.id && s.stueckRowSel,
                      !!editingEintragId && s.stueckRowDisabled,
                    ]}
                    onPress={() => { if (!editingEintragId) setSelectedStueckId(st.id); }}
                    activeOpacity={editingEintragId ? 1 : 0.7}
                  >
                    <View style={[s.stueckDot, { backgroundColor: st.farbe }]} />
                    <View style={s.stueckRowText}>
                      <Text style={[s.stueckRowName, selectedStueckId === st.id && { color: colors.foreground }]}>{st.name}</Text>
                      {st.komponist ? <Text style={s.stueckRowKomp}>{st.komponist}</Text> : null}
                    </View>
                    {selectedStueckId === st.id && <Feather name="check-circle" size={18} color={colors.primary} />}
                  </TouchableOpacity>
                ))}
              </ScrollView>
              {editingEintragId && <Text style={s.editHint}>Das Stück kann beim Bearbeiten nicht geändert werden.</Text>}

              <Text style={s.label}>Uhrzeit (optional)</Text>
              <View style={s.timeRow}>
                <TextInput style={[s.input, s.timeInput]} value={stundenInput}
                  onChangeText={v => setStundenInput(v.replace(/\D/g, "").slice(0, 2))}
                  keyboardType="numeric" placeholder="08" placeholderTextColor={colors.mutedForeground} maxLength={2} />
                <Text style={s.timeSep}>:</Text>
                <TextInput style={[s.input, s.timeInput]} value={minutenInput}
                  onChangeText={v => setMinutenInput(v.replace(/\D/g, "").slice(0, 2))}
                  keyboardType="numeric" placeholder="30" placeholderTextColor={colors.mutedForeground} maxLength={2} />
                <Text style={s.timeLabel}>Uhr</Text>
              </View>

              <Text style={s.label}>Dauer (Minuten)</Text>
              <TextInput style={s.input} value={dauerInput} onChangeText={setDauerInput}
                keyboardType="numeric" placeholder="30" placeholderTextColor={colors.mutedForeground} />

              <Text style={s.label}>Notizen (optional)</Text>
              <TextInput style={[s.input, s.inputMulti]} value={notizenUebungInput}
                onChangeText={setNotizenUebungInput}
                placeholder="z. B. Takt 24–48 langsam üben…"
                placeholderTextColor={colors.mutedForeground} multiline numberOfLines={3} />

              <TouchableOpacity style={[s.saveBtn, !selectedStueckId && s.saveBtnDis]}
                onPress={handleSaveUebung} disabled={!selectedStueckId}>
                <Text style={s.saveBtnText}>{editingEintragId ? "Speichern" : "Hinzufügen"}</Text>
              </TouchableOpacity>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>

      {/* Termin Modal */}
      <Modal visible={showTerminModal} transparent animationType="slide" onRequestClose={() => { setShowTerminModal(false); setEditingTerminId(null); }}>
        <Pressable style={s.overlay} onPress={() => { setShowTerminModal(false); setEditingTerminId(null); }}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={s.kav}>
            <Pressable style={[s.sheet, { paddingBottom: insets.bottom + 24 }]} onPress={() => {}}>
              {/* Sticky header */}
              <View style={s.handle} />
              <Text style={s.sheetTitle}>{editingTerminId ? "Termin bearbeiten" : "Termin hinzufügen"}</Text>

              <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: 8 }}>

                <Text style={s.label}>Name *</Text>
                <TextInput style={[s.input, { borderColor: colors.primary + "80" }]} value={terminNameInput}
                  onChangeText={setTerminNameInput}
                  placeholder="z. B. Klavierstunde, Konzert…"
                  placeholderTextColor={colors.mutedForeground} autoFocus />

                <Text style={s.label}>Farbe</Text>
                <View style={s.colorRow}>
                  {TERMIN_FARBEN.map(f => (
                    <TouchableOpacity
                      key={f} style={[s.colorCircle, { backgroundColor: f }, terminFarbe === f && s.colorCircleSel]}
                      onPress={() => { setTerminFarbe(f); Haptics.selectionAsync(); }}
                    >
                      {terminFarbe === f && <Feather name="check" size={13} color="#fff" />}
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={s.label}>Uhrzeit (optional)</Text>
                <View style={s.timeRow}>
                  <TextInput style={[s.input, s.timeInput]} value={terminStundenInput}
                    onChangeText={v => setTerminStundenInput(v.replace(/\D/g, "").slice(0, 2))}
                    keyboardType="numeric" placeholder="14" placeholderTextColor={colors.mutedForeground} maxLength={2} />
                  <Text style={s.timeSep}>:</Text>
                  <TextInput style={[s.input, s.timeInput]} value={terminMinutenInput}
                    onChangeText={v => setTerminMinutenInput(v.replace(/\D/g, "").slice(0, 2))}
                    keyboardType="numeric" placeholder="00" placeholderTextColor={colors.mutedForeground} maxLength={2} />
                  <Text style={s.timeLabel}>Uhr</Text>
                </View>

                <Text style={s.label}>Enddatum (optional)</Text>
                <View style={[s.timeRow, { marginBottom: 4 }]}>
                  <TextInput style={[s.input, s.timeInput]} value={terminEndTagInput}
                    onChangeText={v => setTerminEndTagInput(v.replace(/\D/g, "").slice(0, 2))}
                    keyboardType="numeric" placeholder="TT" placeholderTextColor={colors.mutedForeground} maxLength={2} />
                  <Text style={s.timeSep}>.</Text>
                  <TextInput style={[s.input, s.timeInput]} value={terminEndMonatInput}
                    onChangeText={v => setTerminEndMonatInput(v.replace(/\D/g, "").slice(0, 2))}
                    keyboardType="numeric" placeholder="MM" placeholderTextColor={colors.mutedForeground} maxLength={2} />
                  <Text style={s.timeSep}>.</Text>
                  <TextInput style={[s.input, { flex: 1.6, textAlign: "center", marginBottom: 0 }]} value={terminEndJahrInput}
                    onChangeText={v => setTerminEndJahrInput(v.replace(/\D/g, "").slice(0, 4))}
                    keyboardType="numeric" placeholder="JJJJ" placeholderTextColor={colors.mutedForeground} maxLength={4} />
                </View>
                <Text style={[s.editHint, { marginBottom: 16 }]}>Nur ausfüllen wenn der Termin mehrere Tage dauert</Text>

                <Text style={s.label}>Notizen (optional)</Text>
                <TextInput style={[s.input, s.inputMulti]} value={notizenTerminInput}
                  onChangeText={setNotizenTerminInput}
                  placeholder="z. B. Lehrer: Herr Müller…"
                  placeholderTextColor={colors.mutedForeground} multiline numberOfLines={3} />

                <TouchableOpacity
                  style={[s.saveBtn, { backgroundColor: terminFarbe }, !terminNameInput.trim() && s.saveBtnDis]}
                  onPress={handleSaveTermin} disabled={!terminNameInput.trim()}>
                  <Text style={s.saveBtnText}>{editingTerminId ? "Speichern" : "Hinzufügen"}</Text>
                </TouchableOpacity>
              </ScrollView>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      </Modal>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    monthNav: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingTop: 12, paddingBottom: 6 },
    navBtn: { padding: 8 },
    monthTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    dayHeader: { flexDirection: "row", paddingHorizontal: 12, paddingBottom: 4 },
    dayHeaderText: { flex: 1, textAlign: "center", fontSize: 11, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase" },
    grid: { paddingHorizontal: 8 },
    gridRow: { flexDirection: "row" },
    dayCell: { flex: 1, aspectRatio: 1, alignItems: "center", justifyContent: "center", margin: 2, borderRadius: 10, gap: 2 },
    dayCellSelected: { backgroundColor: colors.primary },
    dayCellToday: { borderWidth: 1.5, borderColor: colors.primary },
    dayCellText: { fontSize: 14, fontFamily: "Inter_500Medium", color: colors.foreground },
    dayCellTextSelected: { color: colors.primaryForeground, fontFamily: "Inter_700Bold" },
    dayCellTextToday: { color: colors.primary, fontFamily: "Inter_700Bold" },
    dotRow: { flexDirection: "row", gap: 2, alignItems: "center" },
    dot: { width: 4, height: 4, borderRadius: 2, backgroundColor: colors.primary },
    dotSelected: { backgroundColor: colors.primaryForeground },
    dotDone: { backgroundColor: "#43A047" },
    dotTermin: { backgroundColor: "#6366F1" },
    detailSection: { marginTop: 12, paddingHorizontal: 16 },
    detailHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
    detailTitle: { fontSize: 17, fontFamily: "Inter_700Bold", color: colors.foreground },
    // Split button
    splitBtn: { flexDirection: "row", alignItems: "center", backgroundColor: colors.primary, borderRadius: 10, overflow: "hidden" },
    splitMain: { flexDirection: "row", alignItems: "center", gap: 5, paddingLeft: 10, paddingRight: 8, paddingVertical: 8 },
    splitMainText: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.primaryForeground },
    splitDivider: { width: 1, height: 28, backgroundColor: colors.primaryForeground + "40" },
    splitArrow: { paddingHorizontal: 8, paddingVertical: 8, alignItems: "center", justifyContent: "center" },
    // Mode menu
    modeOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.2)", justifyContent: "flex-end", alignItems: "flex-end", paddingRight: 16, paddingBottom: 120 },
    modeMenu: { backgroundColor: colors.card, borderRadius: 14, minWidth: 160, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 8, overflow: "hidden" },
    modeOption: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 16, paddingVertical: 13 },
    modeOptionActive: { backgroundColor: colors.muted },
    modeOptionText: { flex: 1, fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    modeDivider: { height: 1, backgroundColor: colors.border },
    // Empty
    emptyDetail: { paddingVertical: 20, alignItems: "center" },
    emptyDetailText: { fontSize: 14, fontFamily: "Inter_400Regular", color: colors.mutedForeground, textAlign: "center" },
    // Übung card
    eintragCard: { flexDirection: "row", alignItems: "center", backgroundColor: colors.card, borderRadius: 12, marginBottom: 8, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3, elevation: 2 },
    eintragColorBar: { width: 4, alignSelf: "stretch" },
    eintragCheck: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: colors.border, alignItems: "center", justifyContent: "center", marginLeft: 10 },
    eintragInfo: { flex: 1, paddingVertical: 12, paddingLeft: 10, paddingRight: 6 },
    eintragTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 6 },
    eintragName: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.foreground, flex: 1 },
    eintragNameDone: { textDecorationLine: "line-through", color: colors.mutedForeground },
    timeBadge: { flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: colors.muted, borderRadius: 7, paddingHorizontal: 6, paddingVertical: 2 },
    timeBadgeTermin: { backgroundColor: "#6366F110" },
    timeBadgeText: { fontSize: 11, fontFamily: "Inter_600SemiBold", color: colors.primary },
    eintragKomp: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 1 },
    eintragDauer: { fontSize: 12, fontFamily: "Inter_500Medium", color: colors.primary, marginTop: 3 },
    eintragNotizen: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 },
    cardActions: { flexDirection: "column", alignItems: "center", gap: 2, paddingRight: 8, paddingVertical: 8 },
    actionBtn: { padding: 8 },
    // Termin card
    terminCard: { flexDirection: "row", alignItems: "center", backgroundColor: colors.card, borderRadius: 12, marginBottom: 8, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 3, elevation: 2 },
    terminIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: "#6366F118", alignItems: "center", justifyContent: "center", marginLeft: 10 },
    terminName: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.foreground, flex: 1 },
    // Modals
    overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", justifyContent: "flex-end" },
    kav: { justifyContent: "flex-end" },
    sheet: { backgroundColor: colors.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 },
    handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: "center", marginBottom: 20 },
    sheetTitle: { fontSize: 20, fontFamily: "Inter_700Bold", color: colors.foreground, marginBottom: 20 },
    label: { fontSize: 12, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground, textTransform: "uppercase", letterSpacing: 0.6, marginBottom: 8 },
    stueckPicker: { maxHeight: 160, borderWidth: 1, borderColor: colors.border, borderRadius: 12, marginBottom: 4 },
    stueckRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: colors.border, gap: 10 },
    stueckRowLast: { borderBottomWidth: 0 },
    stueckRowSel: { backgroundColor: colors.muted },
    stueckRowDisabled: { opacity: 0.6 },
    stueckDot: { width: 10, height: 10, borderRadius: 5 },
    stueckRowText: { flex: 1 },
    stueckRowName: { fontSize: 14, fontFamily: "Inter_600SemiBold", color: colors.foreground },
    stueckRowKomp: { fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground },
    editHint: { fontSize: 11, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginBottom: 16, marginTop: 4 },
    timeRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 16 },
    timeInput: { flex: 1, textAlign: "center", marginBottom: 0 },
    timeSep: { fontSize: 22, fontFamily: "Inter_700Bold", color: colors.foreground },
    timeLabel: { fontSize: 15, fontFamily: "Inter_500Medium", color: colors.mutedForeground },
    input: { backgroundColor: colors.muted, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 16, fontFamily: "Inter_400Regular", color: colors.foreground, marginBottom: 16, borderWidth: 1, borderColor: colors.border },
    inputMulti: { height: 72, textAlignVertical: "top" },
    saveBtn: { backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 16, alignItems: "center", marginTop: 4 },
    saveBtnDis: { opacity: 0.45 },
    saveBtnText: { fontSize: 16, fontFamily: "Inter_700Bold", color: "#fff" },
    colorRow: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 16 },
    colorCircle: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center" },
    colorCircleSel: { borderWidth: 3, borderColor: "#fff", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 4, elevation: 4 },
  });
}
