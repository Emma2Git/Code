import { useAuth, useSignUp } from "@clerk/expo";
import { Link, useRouter, type Href } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

const GOLD = "#B8962E";
const BG = "#FAFAF7";
const CARD = "#FFFFFF";
const DARK = "#1A1A1A";
const MUTED = "#6B6B6B";
const BORDER = "#E8E4DC";
const ERROR = "#C0392B";

export default function SignUpPage() {
  const { signUp, errors, fetchStatus } = useSignUp();
  const { isSignedIn } = useAuth();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const isLoading = fetchStatus === "fetching";

  const handleSubmit = async () => {
    const { error } = await signUp.password({ emailAddress: email, password });
    if (error) return;
    await signUp.verifications.sendEmailCode();
  };

  const handleVerify = async () => {
    await signUp.verifications.verifyEmailCode({ code });
    if (signUp.status === "complete") {
      await signUp.finalize({
        navigate: ({ decorateUrl }) => {
          const url = decorateUrl("/");
          if (url.startsWith("http")) return;
          router.push(url as Href);
        },
      });
    }
  };

  if (signUp.status === "complete" || isSignedIn) return null;

  if (
    signUp.status === "missing_requirements" &&
    signUp.unverifiedFields.includes("email_address") &&
    signUp.missingFields.length === 0
  ) {
    return (
      <View style={styles.screen}>
        <View style={styles.card}>
          <Text style={styles.title}>E-Mail bestätigen</Text>
          <Text style={styles.subtitle}>Wir haben dir einen Code an {email} geschickt.</Text>
          <TextInput
            style={styles.input}
            value={code}
            placeholder="Bestätigungscode"
            placeholderTextColor={MUTED}
            onChangeText={setCode}
            keyboardType="numeric"
            autoFocus
          />
          {errors.fields.code && <Text style={styles.error}>{errors.fields.code.message}</Text>}
          <Pressable
            style={[styles.button, isLoading && styles.buttonDisabled]}
            onPress={handleVerify}
            disabled={isLoading}
          >
            {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Bestätigen</Text>}
          </Pressable>
          <Pressable style={styles.secondaryBtn} onPress={() => signUp.verifications.sendEmailCode()}>
            <Text style={styles.secondaryText}>Neuen Code senden</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.logoRow}>
          <Text style={styles.logoIcon}>🎹</Text>
          <Text style={styles.logoText}>Klavierübungsplaner</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.title}>Konto erstellen</Text>
          <Text style={styles.subtitle}>Registriere dich, um deine Übungen geräteübergreifend zu speichern.</Text>

          <Text style={styles.label}>E-Mail-Adresse</Text>
          <TextInput
            style={styles.input}
            autoCapitalize="none"
            value={email}
            placeholder="name@example.com"
            placeholderTextColor={MUTED}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoComplete="email"
          />
          {errors.fields.emailAddress && <Text style={styles.error}>{errors.fields.emailAddress.message}</Text>}

          <Text style={styles.label}>Passwort</Text>
          <TextInput
            style={styles.input}
            value={password}
            placeholder="Passwort wählen"
            placeholderTextColor={MUTED}
            secureTextEntry
            onChangeText={setPassword}
            autoComplete="new-password"
          />
          {errors.fields.password && <Text style={styles.error}>{errors.fields.password.message}</Text>}

          <Pressable
            style={[styles.button, (!email || !password || isLoading) && styles.buttonDisabled]}
            onPress={handleSubmit}
            disabled={!email || !password || isLoading}
          >
            {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Registrieren</Text>}
          </Pressable>

          <View style={styles.linkRow}>
            <Text style={styles.linkRowText}>Bereits ein Konto? </Text>
            <Link href="/(auth)/sign-in" asChild>
              <Pressable>
                <Text style={styles.link}>Anmelden</Text>
              </Pressable>
            </Link>
          </View>

          <View nativeID="clerk-captcha" />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  scrollContent: { flexGrow: 1, justifyContent: "center", padding: 24 },
  logoRow: { alignItems: "center", marginBottom: 32 },
  logoIcon: { fontSize: 48, marginBottom: 8 },
  logoText: { fontFamily: "Inter_600SemiBold", fontSize: 20, color: DARK, letterSpacing: 0.3 },
  card: { backgroundColor: CARD, borderRadius: 20, padding: 28, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  title: { fontFamily: "Inter_700Bold", fontSize: 24, color: DARK, marginBottom: 6 },
  subtitle: { fontFamily: "Inter_400Regular", fontSize: 14, color: MUTED, marginBottom: 24, lineHeight: 20 },
  label: { fontFamily: "Inter_500Medium", fontSize: 13, color: DARK, marginBottom: 6 },
  input: { backgroundColor: BG, borderWidth: 1, borderColor: BORDER, borderRadius: 10, padding: 13, fontFamily: "Inter_400Regular", fontSize: 15, color: DARK, marginBottom: 16 },
  button: { backgroundColor: GOLD, borderRadius: 12, paddingVertical: 14, alignItems: "center", marginTop: 4, marginBottom: 16 },
  buttonDisabled: { opacity: 0.5 },
  buttonText: { fontFamily: "Inter_600SemiBold", fontSize: 16, color: "#fff" },
  secondaryBtn: { alignItems: "center", paddingVertical: 8 },
  secondaryText: { fontFamily: "Inter_400Regular", fontSize: 14, color: GOLD },
  error: { fontFamily: "Inter_400Regular", fontSize: 13, color: ERROR, marginTop: -10, marginBottom: 12 },
  linkRow: { flexDirection: "row", justifyContent: "center", alignItems: "center" },
  linkRowText: { fontFamily: "Inter_400Regular", fontSize: 14, color: MUTED },
  link: { fontFamily: "Inter_500Medium", fontSize: 14, color: GOLD },
});
