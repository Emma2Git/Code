import { useSignIn } from "@clerk/expo";
import { Link, useRouter, type Href } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

const GOLD = "#B8962E";
const BG = "#FAFAF7";
const CARD = "#FFFFFF";
const DARK = "#1A1A1A";
const MUTED = "#6B6B6B";
const BORDER = "#E8E4DC";
const ERROR = "#C0392B";

export default function SignInPage() {
  const { signIn, errors, fetchStatus } = useSignIn();
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const isLoading = fetchStatus === "fetching";

  const handleSubmit = async () => {
    const { error } = await signIn.password({ emailAddress: email, password });
    if (error) return;

    if (signIn.status === "complete") {
      await signIn.finalize({
        navigate: ({ decorateUrl }) => {
          const url = decorateUrl("/");
          if (url.startsWith("http")) return;
          router.push(url as Href);
        },
      });
    }
  };

  const handleVerify = async () => {
    await signIn.mfa.verifyEmailCode({ code });
    if (signIn.status === "complete") {
      await signIn.finalize({
        navigate: ({ decorateUrl }) => {
          const url = decorateUrl("/");
          if (url.startsWith("http")) return;
          router.push(url as Href);
        },
      });
    }
  };

  if (signIn.status === "needs_client_trust") {
    return (
      <View style={styles.screen}>
        <View style={styles.card}>
          <Text style={styles.title}>Code bestätigen</Text>
          <Text style={styles.subtitle}>Wir haben dir einen Bestätigungscode per E-Mail geschickt.</Text>
          <TextInput
            style={styles.input}
            value={code}
            placeholder="Bestätigungscode"
            placeholderTextColor={MUTED}
            onChangeText={setCode}
            keyboardType="numeric"
            autoFocus
          />
          {errors.fields.code && <Text style={styles.error}>{errors.fields.code.message}</Text>}
          <Pressable
            style={[styles.button, isLoading && styles.buttonDisabled]}
            onPress={handleVerify}
            disabled={isLoading}
          >
            {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Bestätigen</Text>}
          </Pressable>
          <Pressable style={styles.secondaryBtn} onPress={() => signIn.mfa.sendEmailCode()}>
            <Text style={styles.secondaryText}>Neuen Code senden</Text>
          </Pressable>
          <Pressable style={styles.secondaryBtn} onPress={() => signIn.reset()}>
            <Text style={styles.secondaryText}>Zurück</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.logoRow}>
          <Text style={styles.logoIcon}>🎹</Text>
          <Text style={styles.logoText}>Klavierübungsplaner</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.title}>Willkommen zurück</Text>
          <Text style={styles.subtitle}>Melde dich an, um deine Übungen zu synchronisieren.</Text>

          <Text style={styles.label}>E-Mail-Adresse</Text>
          <TextInput
            style={styles.input}
            autoCapitalize="none"
            value={email}
            placeholder="name@example.com"
            placeholderTextColor={MUTED}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoComplete="email"
          />
          {errors.fields.identifier && <Text style={styles.error}>{errors.fields.identifier.message}</Text>}

          <Text style={styles.label}>Passwort</Text>
          <TextInput
            style={styles.input}
            value={password}
            placeholder="Passwort eingeben"
            placeholderTextColor={MUTED}
            secureTextEntry
            onChangeText={setPassword}
            autoComplete="current-password"
          />
          {errors.fields.password && <Text style={styles.error}>{errors.fields.password.message}</Text>}

          <Pressable
            style={[styles.button, (!email || !password || isLoading) && styles.buttonDisabled]}
            onPress={handleSubmit}
            disabled={!email || !password || isLoading}
          >
            {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Anmelden</Text>}
          </Pressable>

          <View style={styles.linkRow}>
            <Text style={styles.linkRowText}>Noch kein Konto? </Text>
            <Link href="/(auth)/sign-up" asChild>
              <Pressable>
                <Text style={styles.link}>Registrieren</Text>
              </Pressable>
            </Link>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  scrollContent: { flexGrow: 1, justifyContent: "center", padding: 24 },
  logoRow: { alignItems: "center", marginBottom: 32 },
  logoIcon: { fontSize: 48, marginBottom: 8 },
  logoText: { fontFamily: "Inter_600SemiBold", fontSize: 20, color: DARK, letterSpacing: 0.3 },
  card: { backgroundColor: CARD, borderRadius: 20, padding: 28, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  title: { fontFamily: "Inter_700Bold", fontSize: 24, color: DARK, marginBottom: 6 },
  subtitle: { fontFamily: "Inter_400Regular", fontSize: 14, color: MUTED, marginBottom: 24, lineHeight: 20 },
  label: { fontFamily: "Inter_500Medium", fontSize: 13, color: DARK, marginBottom: 6 },
  input: { backgroundColor: BG, borderWidth: 1, borderColor: BORDER, borderRadius: 10, padding: 13, fontFamily: "Inter_400Regular", fontSize: 15, color: DARK, marginBottom: 16 },
  button: { backgroundColor: GOLD, borderRadius: 12, paddingVertical: 14, alignItems: "center", marginTop: 4, marginBottom: 16 },
  buttonDisabled: { opacity: 0.5 },
  buttonText: { fontFamily: "Inter_600SemiBold", fontSize: 16, color: "#fff" },
  secondaryBtn: { alignItems: "center", paddingVertical: 8 },
  secondaryText: { fontFamily: "Inter_400Regular", fontSize: 14, color: GOLD },
  error: { fontFamily: "Inter_400Regular", fontSize: 13, color: ERROR, marginTop: -10, marginBottom: 12 },
  linkRow: { flexDirection: "row", justifyContent: "center", alignItems: "center" },
  linkRowText: { fontFamily: "Inter_400Regular", fontSize: 14, color: MUTED },
  link: { fontFamily: "Inter_500Medium", fontSize: 14, color: GOLD },
});
