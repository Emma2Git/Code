const colors = {
  light: {
    text: "#1C1917",
    tint: "#B8962E",
    background: "#FAFAF7",
    foreground: "#1C1917",
    card: "#FFFFFF",
    cardForeground: "#1C1917",
    primary: "#B8962E",
    primaryForeground: "#FFFFFF",
    secondary: "#F5F0E8",
    secondaryForeground: "#1C1917",
    muted: "#EDE8DF",
    mutedForeground: "#8B7E6E",
    accent: "#B8962E",
    accentForeground: "#FFFFFF",
    destructive: "#DC2626",
    destructiveForeground: "#FFFFFF",
    border: "#DDD8CE",
    input: "#DDD8CE",
  },
  radius: 12,
};

export default colors;
