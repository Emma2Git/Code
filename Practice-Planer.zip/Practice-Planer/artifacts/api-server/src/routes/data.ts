import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, stueckeTable, uebungsEintraegeTable, stoppuhrSessionsTable, termineTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const dataRouter = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Nicht autorisiert" });
  req.userId = userId;
  next();
}

dataRouter.get("/data", requireAuth, async (req: any, res) => {
  try {
    const userId: string = req.userId;
    const [stuecke, eintraege, sessions, termine] = await Promise.all([
      db.select().from(stueckeTable).where(eq(stueckeTable.userId, userId)),
      db.select().from(uebungsEintraegeTable).where(eq(uebungsEintraegeTable.userId, userId)),
      db.select().from(stoppuhrSessionsTable).where(eq(stoppuhrSessionsTable.userId, userId)),
      db.select().from(termineTable).where(eq(termineTable.userId, userId)),
    ]);
    res.json({
      stuecke: stuecke.map(({ userId: _u, createdAt: _c, ...s }) => s),
      eintraege: eintraege.map(({ userId: _u, createdAt: _c, stueckId, dauerMinuten, ...e }) => ({ ...e, stueckId, dauerMinuten })),
      sessions: sessions.map(({ userId: _u, createdAt: _c, stueckId, ...s }) => ({ ...s, stueckId })),
      termine: termine.map(({ userId: _u, createdAt: _c, ...t }) => t),
    });
  } catch (err) {
    req.log.error(err, "GET /data failed");
    res.status(500).json({ error: "Serverfehler" });
  }
});

dataRouter.post("/data", requireAuth, async (req: any, res) => {
  try {
    const userId: string = req.userId;
    const { stuecke = [], eintraege = [], sessions = [], termine = [] } = req.body;

    await db.transaction(async (tx) => {
      await tx.delete(stueckeTable).where(eq(stueckeTable.userId, userId));
      await tx.delete(uebungsEintraegeTable).where(eq(uebungsEintraegeTable.userId, userId));
      await tx.delete(stoppuhrSessionsTable).where(eq(stoppuhrSessionsTable.userId, userId));
      await tx.delete(termineTable).where(eq(termineTable.userId, userId));

      if (stuecke.length > 0) {
        await tx.insert(stueckeTable).values(
          stuecke.map((s: any) => ({ ...s, userId }))
        );
      }
      if (eintraege.length > 0) {
        await tx.insert(uebungsEintraegeTable).values(
          eintraege.map((e: any) => ({ ...e, userId, stueckId: e.stueckId, dauerMinuten: e.dauerMinuten }))
        );
      }
      if (sessions.length > 0) {
        await tx.insert(stoppuhrSessionsTable).values(
          sessions.map((s: any) => ({ ...s, userId, stueckId: s.stueckId }))
        );
      }
      if (termine.length > 0) {
        await tx.insert(termineTable).values(
          termine.map((t: any) => ({
            id: t.id, datum: t.datum, endDatum: t.endDatum ?? null,
            name: t.name, uhrzeit: t.uhrzeit ?? null,
            notizen: t.notizen ?? null, farbe: t.farbe ?? null, userId,
          }))
        );
      }
    });

    res.json({ ok: true });
  } catch (err) {
    req.log.error(err, "POST /data failed");
    res.status(500).json({ error: "Serverfehler" });
  }
});

export default dataRouter;
