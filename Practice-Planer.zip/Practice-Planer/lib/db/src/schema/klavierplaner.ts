import { pgTable, text, boolean, integer, timestamp } from "drizzle-orm/pg-core";

export const stueckeTable = pgTable("stuecke", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  komponist: text("komponist"),
  notizen: text("notizen"),
  farbe: text("farbe").notNull(),
  foto: text("foto"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const uebungsEintraegeTable = pgTable("uebungs_eintraege", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  datum: text("datum").notNull(),
  stueckId: text("stueck_id").notNull(),
  dauerMinuten: integer("dauer_minuten").notNull(),
  notizen: text("notizen"),
  uhrzeit: text("uhrzeit"),
  erledigt: boolean("erledigt").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stoppuhrSessionsTable = pgTable("stoppuhr_sessions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  stueckId: text("stueck_id").notNull(),
  sekunden: integer("sekunden").notNull(),
  datum: text("datum").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const termineTable = pgTable("termine", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  datum: text("datum").notNull(),
  endDatum: text("end_datum"),
  name: text("name").notNull(),
  uhrzeit: text("uhrzeit"),
  notizen: text("notizen"),
  farbe: text("farbe"),
  createdAt: timestamp("created_at").defaultNow(),
});
