# Klavierübungsplaner

Eine deutsche Klavier-Übungsplaner-App (Expo/React Native) mit Kalender, Stoppuhr, Statistik und Stücke-Verwaltung — jetzt mit Benutzer-Authentifizierung und Cloud-Datenspeicherung.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — API-Server starten (Port 8080, via Proxy auf /api)
- `pnpm --filter @workspace/mobile run dev` — Expo Dev-Server starten
- `pnpm run typecheck` — Vollständige Typprüfung aller Pakete
- `pnpm run typecheck:libs` — Nur Bibliotheken bauen (vor API-Server-Typecheck nötig)
- `pnpm --filter @workspace/db run push` — DB-Schema-Änderungen pushen (nur Dev)
- Required env: `DATABASE_URL`, `CLERK_SECRET_KEY`, `CLERK_PUBLISHABLE_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Mobile: Expo ~54, expo-router ~6, React Native 0.81.5
- API: Express 5 + Clerk Express Middleware
- Auth: Clerk (@clerk/expo auf Mobile, @clerk/express auf Server)
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/mobile/` — Expo React Native App
  - `app/_layout.tsx` — Root-Layout mit ClerkProvider + ClerkLoaded
  - `app/(auth)/` — Anmeldebildschirme (sign-in, sign-up)
  - `app/(tabs)/` — Hauptnavigation (5 Tabs)
  - `context/AppContext.tsx` — Globaler State mit AsyncStorage + Cloud-Sync
- `artifacts/api-server/` — Express API Server
  - `src/app.ts` — Express-App mit Clerk-Middleware
  - `src/routes/data.ts` — GET/POST /api/data (bulk sync)
- `lib/db/src/schema/klavierplaner.ts` — Drizzle-Schema (stuecke, uebungs_eintraege, stoppuhr_sessions)

## Architecture decisions

- **Bulk-Sync-Ansatz**: Statt einzelner CRUD-Endpunkte wird der gesamte Datensatz mit GET/POST /api/data synchronisiert. Einfacher, robust, gut für mobile Nutzung.
- **AsyncStorage + Cloud-Sync**: AsyncStorage bleibt als schneller lokaler Cache. Cloud-Sync ist debounced (1,5s) nach jeder Änderung.
- **Clerk Auth required**: Nicht angemeldete Nutzer werden zum Anmeldebildschirm weitergeleitet. Daten ohne Account bleiben in AsyncStorage.
- **NativeTabs auf iOS 26+**: Liquid Glass Tabs wenn verfügbar, sonst klassische Tabs mit BlurView.
- **AppProvider nutzt useAuth()**: AppProvider liegt innerhalb von ClerkLoaded und kann Clerk-Hooks direkt verwenden.

## Product

- **Heute-Tab**: Heutige Übungseinträge auf einen Blick, abhaken wenn erledigt
- **Kalender-Tab**: Monatsansicht, Einträge pro Tag planen und verwalten
- **Stoppuhr-Tab**: Timer mit Stück-Auswahl, Sessions werden gespeichert und synchronisiert
- **Statistik-Tab**: Pro-Stück Zielvorgaben mit Fortschrittsanzeige (Carousel)
- **Stücke-Tab**: Stücke mit Name, Komponist, Farbe und Notizen verwalten

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Nach Änderungen an `lib/db/src/schema/`: `pnpm run typecheck:libs` ausführen, sonst schlägt API-Server-Typecheck fehl.
- Mobile Typecheck hat einen pre-existierenden Fehler mit `"calendar.fill"` SF-Symbol — kein Laufzeitproblem.
- `expo-auth-session` ist bereits in den devDependencies (`expo-web-browser@~15.0.10`).

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- See the `clerk-auth` skill for Clerk auth implementation guidance
